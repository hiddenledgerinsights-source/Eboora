# Run EBOORA in Termux

```sh
pkg update -y
pkg install -y unzip
unzip eboora-full-project-runnable.zip
cd eboora
chmod +x run-termux.sh
./run-termux.sh
```

Open http://127.0.0.1:3000 in Chrome on the same phone. Keep Termux open while testing. If Node is missing, the script attempts to install `nodejs-lts`. Internet is required for dependency installation. Authentication, orders and checkout require a configured PostgreSQL database; payment integrations must be sandbox-tested separately.


### Android SWC compiler workaround
Next.js does not publish a native SWC binary for this Android/ARM64 Termux environment in the configured package set. The Termux launcher installs the matching `@next/swc-wasm-nodejs` package and patches the installed Next.js SWC loader to try WASM first on Android. The patch only changes `node_modules` and is re-applied by `run-termux.sh` if dependencies are reinstalled.
