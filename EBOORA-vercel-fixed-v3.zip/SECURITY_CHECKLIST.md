# Security checklist

## Before any public staging deployment

- [ ] Use a separate staging database and sandbox payment credentials.
- [ ] Generate unique secrets: `openssl rand -base64 48` for download signing and cron authorization.
- [ ] Ensure `.env.local` and all `.env.*` secrets except `.env.example` are ignored by Git.
- [ ] Use managed PostgreSQL TLS, least-privilege credentials, automated backups, and a tested restore.
- [ ] Verify every admin server action and route checks authorization on the server.
- [ ] Test session expiry, logout invalidation, password reset expiry, and login rate limiting.
- [ ] Test customer A cannot read customer B's orders, download grants, or email data.
- [ ] Confirm product files live in a private bucket with no public object access.
- [ ] Implement provider-specific webhook signature verification against the exact raw request body before processing events.
- [ ] Check amount, currency, provider order reference, payment ID, and final provider status before fulfillment.
- [ ] Make webhook handling idempotent for both event IDs and payment IDs; do not mark an order paid if a payment ID is already associated with a different order.
- [ ] Rate-limit login, password reset, checkout, download, review, coupon, and analytics endpoints as appropriate.
- [ ] Check upload MIME type, extension, size, and actual file signature; never trust the browser-provided MIME type alone.
- [ ] Avoid logging passwords, session tokens, API keys, raw webhook payloads with unnecessary personal data, or signed download tokens.
- [ ] Review security headers and test all required third-party scripts before introducing a restrictive CSP.
- [ ] Check that analytics scripts and events do not run before consent where consent is required.
- [ ] Review privacy, terms, refund, delivery, and contact pages with appropriate legal advice before publishing.

## Before live payments

- [ ] Cashfree account and production credentials approved and verified.
- [ ] Sandbox payment success, failure, cancellation, delayed webhook, invalid signature, duplicate webhook, amount mismatch and replay tests pass.
- [ ] Confirm the success redirect alone never marks an order paid.
- [ ] Confirm refunds are reconciled with the provider and update order/download access correctly.
- [ ] Run a low-value live smoke test manually only after all sandbox checks pass and the merchant is approved.
- [ ] Configure alerts for webhook failures, pending orders, email queue growth, DB errors, and failed downloads.
- [ ] Rotate any secret that may have been pasted into chats, logs, or public repositories.

## Incident response

1. Disable checkout or revoke affected provider credentials if payment integrity may be compromised.
2. Rotate database, email, storage, cron, and payment secrets as relevant.
3. Preserve audit logs and provider transaction IDs; avoid copying sensitive payloads into tickets.
4. Restore from a known-good backup only after identifying the cause.
5. Reconcile all pending/paid/refunded orders against the payment provider before re-enabling fulfillment.
