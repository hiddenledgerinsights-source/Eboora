#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then echo 'Node.js 20+ is required.'; exit 1; fi
if [ ! -f .env.local ]; then cp .env.example .env.local; echo 'Created .env.local from .env.example. Edit DATABASE_URL and secrets before continuing.'; fi
if [ ! -d node_modules ]; then npm install; fi
echo 'Starting Next.js dev server. PostgreSQL must be running and .env.local configured.'
npm run dev
