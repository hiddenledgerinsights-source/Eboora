# EBOORA — Start here

This ZIP contains the full multi-file Next.js project. A production full-stack application cannot safely be delivered as one source-code file; keep the folder structure intact.

## Requirements
- Node.js 20+
- PostgreSQL 14+ (local or managed)
- Internet access for `npm install`

## Run locally
1. Extract the ZIP.
2. Open the `eboora` folder.
3. Copy `.env.example` to `.env.local` (the launch scripts do this automatically).
4. Edit `DATABASE_URL` in `.env.local` for your PostgreSQL database. Set strong random values for `DOWNLOAD_SIGNING_SECRET` and `CRON_SECRET`.
5. Run `run-local.bat` on Windows or `./run-local.sh` on macOS/Linux. Alternatively run `npm install` then `npm run dev`.
6. Apply database migrations and sample data in a terminal with PostgreSQL access:
   - `npm run db:migrate`
   - `npm run db:seed`
7. Open `http://localhost:3000`.

## Important
- The archive is the whole project, not a single HTML file.
- The app has not been build-tested in this environment because dependency installation timed out.
- Cashfree order creation/webhook verification, private object storage, and transactional email adapters remain unimplemented. Do not use live payment credentials or launch live sales until those integrations are completed and sandbox-tested.
- Read `README.md`, `ACCEPTANCE_STATUS.md`, `DEPLOYMENT.md`, and `SECURITY_CHECKLIST.md` before deployment.

## Android / Termux
1. Install Termux from a trusted source and open it.
2. Extract this ZIP, then `cd` into the `eboora` project folder.
3. Run `chmod +x run-termux.sh && ./run-termux.sh`.
4. Open `http://127.0.0.1:3000` in your phone browser.
5. Stop the server with `Ctrl+C`.

The public homepage and static catalog can be previewed without PostgreSQL. Registration, login, reviews, orders, downloads, and admin actions require a reachable PostgreSQL database and migrations. The app intentionally shows a friendly unavailable message if registration/login cannot reach the database; it does not create fake accounts. Configure a real PostgreSQL `DATABASE_URL` and secrets in `.env.local` before testing those features. Cashfree payments and private storage are not ready for live use. Do not use live payment credentials while testing.

## UI notes
The storefront has responsive mobile and desktop layouts. Mobile pinch-to-zoom is disabled in the viewport settings as requested; this can reduce accessibility for users who rely on zoom. Browser-level desktop zoom cannot reliably be disabled by a website.


## Wasmer PostgreSQL configuration note
The database client accepts either `DATABASE_URL` or Wasmer's individual `DB_HOST`, `DB_NAME`, `DB_USERNAME` (or `DB_USER`), `DB_PORT`, and `DB_PASSWORD` variables. If the managed database requires TLS, set `DB_SSL=true` or provide a `DATABASE_URL` with the provider's documented TLS parameters. Do not put database credentials in source control. Apply migrations as a separate release step; the app build does not run SQL migrations automatically.
