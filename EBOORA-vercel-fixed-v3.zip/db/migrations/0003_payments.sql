-- Phase 3: records every verified provider webhook so duplicates are detected.
CREATE TABLE webhook_events (
  id          text PRIMARY KEY,              -- provider event id: deduplication key
  provider    text NOT NULL DEFAULT 'cashfree',
  event_type  text NOT NULL,
  processed   boolean NOT NULL DEFAULT false,
  received_at timestamptz NOT NULL DEFAULT now()
);
