-- Phase 5: reviews (buyers only, moderated) and first-party analytics (no IPs, no user IDs).
CREATE TABLE reviews (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id        uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  user_id           uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  author_name       text NOT NULL,
  rating            integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
  body              text NOT NULL CHECK (char_length(body) BETWEEN 10 AND 2000),
  verified_purchase boolean NOT NULL DEFAULT true,
  status            text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','hidden')),
  created_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (product_id, user_id)
);
CREATE INDEX reviews_product_status_idx ON reviews(product_id, status);

CREATE TABLE analytics_events (
  id             bigserial PRIMARY KEY,
  name           text NOT NULL CHECK (name IN ('page_view','view_content','checkout_start')),
  path           text NOT NULL CHECK (char_length(path) <= 300),
  product_id     uuid REFERENCES products(id) ON DELETE SET NULL,
  utm_source     text,
  utm_medium     text,
  utm_campaign   text,
  referrer_host  text,
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX analytics_events_time_idx ON analytics_events(created_at);
