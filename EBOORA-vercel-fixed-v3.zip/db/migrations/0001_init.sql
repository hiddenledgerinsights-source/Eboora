-- EBOORA initial schema (Phase 1). Money is stored as integer paise (INR minor units).
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email         text NOT NULL UNIQUE CHECK (email = lower(email)),
  password_hash text,
  full_name     text,
  role          text NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','admin')),
  email_verified_at timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE categories (
  id   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL
);

CREATE TABLE products (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug               text NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9-]+$'),
  title              text NOT NULL,
  short_description  text NOT NULL DEFAULT '',
  long_description   text NOT NULL DEFAULT '',
  category_id        uuid REFERENCES categories(id) ON DELETE SET NULL,
  original_price_paise integer NOT NULL CHECK (original_price_paise >= 0),
  sale_price_paise     integer NOT NULL CHECK (sale_price_paise >= 0),
  currency           char(3) NOT NULL DEFAULT 'INR' CHECK (currency = 'INR'),
  status             text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  seo_title          text,
  seo_description    text,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  CHECK (sale_price_paise <= original_price_paise)
);
CREATE INDEX products_status_idx ON products(status);

CREATE TABLE product_files (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id    uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  version       integer NOT NULL DEFAULT 1 CHECK (version >= 1),
  storage_key   text NOT NULL UNIQUE,           -- private bucket path, never public
  file_name     text NOT NULL,
  mime_type     text NOT NULL CHECK (mime_type IN ('application/pdf','application/zip')),
  size_bytes    bigint NOT NULL CHECK (size_bytes > 0 AND size_bytes <= 524288000),
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (product_id, version)
);

CREATE TABLE product_faqs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id  uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  question    text NOT NULL,
  answer      text NOT NULL,
  position    integer NOT NULL DEFAULT 0
);

CREATE TABLE coupons (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code                 text NOT NULL UNIQUE CHECK (code = upper(code)),
  discount_type        text NOT NULL CHECK (discount_type IN ('percent','fixed')),
  discount_value       integer NOT NULL CHECK (discount_value > 0),
  CHECK (discount_type <> 'percent' OR discount_value <= 100),
  min_order_paise      integer NOT NULL DEFAULT 0 CHECK (min_order_paise >= 0),
  product_id           uuid REFERENCES products(id) ON DELETE CASCADE,
  max_redemptions      integer CHECK (max_redemptions IS NULL OR max_redemptions > 0),
  expires_at           timestamptz,
  is_active            boolean NOT NULL DEFAULT true
);

CREATE TABLE orders (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  public_order_ref     text NOT NULL UNIQUE,
  user_id              uuid REFERENCES users(id) ON DELETE SET NULL,
  customer_email       text NOT NULL,
  subtotal_paise       integer NOT NULL CHECK (subtotal_paise >= 0),
  discount_paise       integer NOT NULL DEFAULT 0 CHECK (discount_paise >= 0),
  total_paise          integer NOT NULL CHECK (total_paise >= 0),
  currency             char(3) NOT NULL DEFAULT 'INR' CHECK (currency = 'INR'),
  coupon_id            uuid REFERENCES coupons(id) ON DELETE SET NULL,
  status               text NOT NULL DEFAULT 'pending'
                       CHECK (status IN ('pending','paid','failed','cancelled','refunded')),
  paid_at              timestamptz,
  created_at           timestamptz NOT NULL DEFAULT now(),
  CHECK (total_paise = subtotal_paise - discount_paise)
);
CREATE INDEX orders_user_idx ON orders(user_id);

CREATE TABLE order_items (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id             uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id           uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  unit_price_paise     integer NOT NULL CHECK (unit_price_paise >= 0),
  quantity             integer NOT NULL DEFAULT 1 CHECK (quantity = 1)
);

CREATE TABLE payment_attempts (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id             uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  provider             text NOT NULL DEFAULT 'cashfree',
  provider_order_id    text UNIQUE,
  status               text NOT NULL DEFAULT 'created'
                       CHECK (status IN ('created','pending','success','failed','cancelled')),
  created_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE payment_transactions (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id             uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  provider_payment_id  text NOT NULL UNIQUE,    -- idempotency key from provider
  amount_paise         integer NOT NULL CHECK (amount_paise > 0),
  currency             char(3) NOT NULL DEFAULT 'INR',
  raw_event_hash       text NOT NULL,
  verified_at          timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE download_grants (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id      uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_file_id uuid NOT NULL REFERENCES product_files(id) ON DELETE RESTRICT,
  max_downloads integer NOT NULL DEFAULT 5 CHECK (max_downloads > 0),
  downloads_used integer NOT NULL DEFAULT 0 CHECK (downloads_used >= 0),
  expires_at    timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (order_id, product_file_id)
);

CREATE TABLE download_logs (
  id          bigserial PRIMARY KEY,
  grant_id    uuid NOT NULL REFERENCES download_grants(id) ON DELETE CASCADE,
  ip_hash     text,
  succeeded   boolean NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE audit_logs (
  id          bigserial PRIMARY KEY,
  actor_id    uuid REFERENCES users(id) ON DELETE SET NULL,
  action      text NOT NULL,
  target      text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
