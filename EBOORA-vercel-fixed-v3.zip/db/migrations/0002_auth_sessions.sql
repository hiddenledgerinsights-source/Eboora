-- Phase 2: server-side sessions. Only a SHA-256 hash of the session token is stored.
CREATE TABLE sessions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  text NOT NULL UNIQUE,
  expires_at  timestamptz NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX sessions_expires_idx ON sessions(expires_at);
-- Used for login rate limiting (failed attempts per email in a time window).
CREATE INDEX audit_logs_login_idx ON audit_logs(action, target, created_at);
