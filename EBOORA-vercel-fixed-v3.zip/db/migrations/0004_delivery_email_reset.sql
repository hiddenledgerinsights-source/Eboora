-- Phase 4: password reset, email queue, and download log indexing.
CREATE TABLE password_reset_tokens (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  text NOT NULL UNIQUE,
  expires_at  timestamptz NOT NULL,
  used_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE email_logs (
  id          bigserial PRIMARY KEY,
  order_id    uuid REFERENCES orders(id) ON DELETE SET NULL,
  to_address  text NOT NULL,
  template    text NOT NULL CHECK (template IN ('order_confirmation','payment_failed')),
  status      text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sending','sent','failed')),
  attempts    integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  last_error  text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  sent_at     timestamptz
);
CREATE INDEX email_logs_queue_idx ON email_logs(status, created_at);
CREATE INDEX download_logs_grant_time_idx ON download_logs(grant_id, created_at);
