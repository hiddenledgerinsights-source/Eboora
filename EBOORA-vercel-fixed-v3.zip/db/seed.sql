-- Sample data for development only. Not real reviews or sales.
INSERT INTO categories (slug, name) VALUES ('fitness', 'Fitness') ON CONFLICT (slug) DO NOTHING;

INSERT INTO products (slug, title, short_description, long_description, category_id,
  original_price_paise, sale_price_paise, status, seo_title, seo_description)
SELECT 'home-workout-30-day-fitness-bundle',
  'Best Home Workout to Be Fit — 30-Day Fitness Bundle',
  'A 30-day home workout plan you can follow with no equipment.',
  'A beginner-friendly 30-day structure for building a home movement routine. Review the plan at your own pace, adapt activity to your current ability, and take rest days when needed. Development placeholder: add and verify the final PDF/ZIP files before accepting payment.',
  c.id, 29900, 19900, 'published',
  'Home Workout 30-Day Fitness Bundle | EBOORA',
  'A 30-day home workout bundle (PDF and ZIP) for beginners. No equipment needed.'
FROM categories c WHERE c.slug = 'fitness'
ON CONFLICT (slug) DO NOTHING;
