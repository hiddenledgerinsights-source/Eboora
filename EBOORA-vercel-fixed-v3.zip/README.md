# EBOORA — Full-stack digital product store (Phase 6 handoff)

EBOORA is a Next.js 15.5 / TypeScript application scaffold for an India-first digital download store. This repository consolidates the latest supplied Phase 5 project and adds Phase 6 release-readiness files: baseline security headers, a database-aware health endpoint, a cleaned environment template, deployment/security runbooks, and an explicit integration status report.

> **Important:** this is not yet safe to launch for live payments. Cashfree order creation and webhook verification, private storage, and transactional email are deliberately fail-closed stubs. The project must not be described as accepting payments or delivering files end-to-end until those adapters are implemented from current provider docs and sandbox-tested.

## Stack

- Next.js 15.5.28 App Router, React 19.2.9, TypeScript
- PostgreSQL via `pg`
- Server actions and server-side session/auth helpers
- Vitest unit tests
- Provider boundaries for Cashfree, email, and private storage

## Local setup

Prerequisites: Node.js 20+, npm, PostgreSQL 14+ (or a compatible managed PostgreSQL instance), and `psql` for migrations.

1. Extract this project and enter the `eboora` directory.
2. Install dependencies: `npm ci` (or `npm install` if no lockfile has been generated yet).
3. Copy `.env.example` to `.env.local` and fill in a local PostgreSQL connection string and a random `DOWNLOAD_SIGNING_SECRET` / `CRON_SECRET`.
4. Create an empty database, then run `npm run db:migrate` and `npm run db:seed`.
5. Run `npm test`.
6. Run `npm run dev` and open `http://localhost:3000`.

This archive does not include a generated `package-lock.json`. After a successful install, generate and commit one (`npm install` creates it) and review it before deployment; without a lockfile, transitive dependency versions are not fully reproducible.

## Database and admin bootstrap

Migrations are ordered `db/migrations/0001_init.sql` through `0005_marketing_reviews.sql`. Run them only once against the intended database; each migration is expected to be safe for its intended first application, not a replacement for a migration-history tool.

Registration creates customer accounts. To promote your own account after registering, run this command in a trusted SQL session and replace the email:

```sql
UPDATE users SET role = 'admin' WHERE email = 'you@example.com';
```

Do not expose SQL/database credentials in a browser or public repository.

## Useful scripts

- `npm run dev` — local development server
- `npm run build` — production build
- `npm start` — serve a built app
- `npm test` — run Vitest unit tests
- `npm run db:migrate` — apply SQL migrations using `DATABASE_URL`
- `npm run db:seed` — insert sample seed data

## Phase 6 additions

- `next.config.js`: baseline security headers and disables the `X-Powered-By` header.
- `src/app/api/health/route.ts`: returns 200 only when PostgreSQL responds to `SELECT 1`; failure details are not exposed.
- `.gitignore`: ignores secrets, build output, dependencies, and local logs.
- `.env.example`: safe placeholders and explicit integration sections.
- `DEPLOYMENT.md`, `SECURITY_CHECKLIST.md`, `ACCEPTANCE_STATUS.md`: launch instructions and honest integration/test status.

## Deployment

Follow [DEPLOYMENT.md](./DEPLOYMENT.md). Do not add live Cashfree keys until the adapter is implemented and sandbox tests pass. Keep private storage credentials server-only. Use HTTPS, managed PostgreSQL with backups, and an external transactional email provider only after its adapter is implemented and a test email is received.

## Known limitations

See [ACCEPTANCE_STATUS.md](./ACCEPTANCE_STATUS.md). In particular, the Cashfree provider, email provider, and private object storage provider are stubs; browser Meta Pixel/GA behavior and database flows have not been verified in a real browser or production-like environment; legal pages are drafts with placeholders and require review before publication.
