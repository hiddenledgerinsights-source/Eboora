# Deployment guide (staging first)

## Recommended topology

- **Web app:** a managed platform that supports Next.js App Router/server actions (for example Vercel or a Node.js container host).
- **Database:** managed PostgreSQL with TLS, automated backups and point-in-time recovery where available.
- **Private files:** a private S3-compatible or Supabase Storage bucket, accessed only from server code. The current storage adapter is not implemented yet.
- **Email:** transactional provider with a verified sender domain. The current email adapter is not implemented yet.
- **Payments:** Cashfree sandbox first. The current Cashfree adapter is not implemented yet.
- **Domain:** custom domain with HTTPS; set `NEXT_PUBLIC_SITE_URL` to the final canonical origin.

Free plans and quotas change frequently and may impose sleep, build-minute, bandwidth, database-size, or retention limits. Confirm current pricing and limits with each vendor before choosing a plan. A free tier is not a guarantee of production reliability or unlimited use.

## Deployment steps

1. Create a private Git repository and push the project. Confirm `.env.local` and all real secrets are absent from Git history.
2. Create a staging PostgreSQL database and store `DATABASE_URL` as a server-side environment variable. Require TLS for hosted database connections.
3. Set environment variables in the hosting dashboard. Use strong unique values for `DOWNLOAD_SIGNING_SECRET` and `CRON_SECRET`; do not reuse production secrets in staging.
4. Generate a lockfile locally with the selected Node/npm versions (`npm install`) and commit `package-lock.json`.
5. Install dependencies using `npm ci`; run `npm test`; run `npm run build`. Do not deploy if any command fails.
6. Apply migrations from a controlled release step: `npm run db:migrate`. Inspect output before running `npm run db:seed`; seed data is for development/staging only and should not be treated as production catalog content without review.
7. Deploy to staging. Confirm `GET /api/health` returns `200` with `{ "status": "ok", "database": "ok" }`.
8. Connect the domain and wait for the host's HTTPS certificate. Set `NEXT_PUBLIC_SITE_URL=https://your-domain.example` and redeploy.
9. Verify security headers, canonical URLs, sitemap, robots.txt, responsive product pages, registration, login, admin permissions and customer isolation.
10. Do not configure live payment credentials. Finish the Cashfree adapter and run sandbox tests before enabling checkout.
11. Configure Cashfree's webhook URL only after signature verification is implemented. Test webhook retries and idempotency in sandbox.
12. Configure private file storage and verify direct public object URLs are inaccessible. Test entitlement checks and expired download links.
13. Configure transactional email, SPF/DKIM/DMARC and a verified sender. Send a real test email before marking email delivery active.
14. Configure Pixel/GA IDs only after consent behavior and privacy notices have been reviewed. Verify events in provider test/debug tools.
15. Replace all draft legal text and placeholders; obtain appropriate legal/tax review before launch.

## Database migration and rollback

- Take a backup before each production migration.
- Apply migrations once in ascending order with `npm run db:migrate` from a controlled environment with `DATABASE_URL` set.
- Do not manually edit old migrations after they have been applied. Add a new numbered migration for schema changes.
- If a deployment fails, roll back the application to the previous known-good build. Do not blindly roll back database DDL; use a reviewed forward-fix migration unless the migration has a tested rollback plan.
- Test restoring a backup to a separate database at least once before launch.

## Production smoke test

- [ ] Homepage, product listing, product details and legal pages load over HTTPS.
- [ ] Admin endpoints reject a logged-out customer and a logged-in non-admin.
- [ ] Customer A cannot access Customer B's order/account/download.
- [ ] Invalid and expired download tokens fail without revealing file paths.
- [ ] Cashfree sandbox payment success and failure paths pass; no real charge is made by automated tests.
- [ ] Webhook signature, amount/currency, duplicate event, and duplicate payment ID tests pass.
- [ ] Order confirmation email is received only after verified payment.
- [ ] Browser refresh does not duplicate purchase analytics; CAPI is separately tested if enabled.
- [ ] Database backup and restoration procedure is documented and tested.
- [ ] Monitoring and a responsible support contact are configured.

## External accounts / approvals needed

- Managed PostgreSQL account and database.
- Hosting account and custom domain/DNS access.
- Cashfree merchant account, sandbox credentials and later production approval/credentials.
- Private object storage account and server-side credentials.
- Transactional email provider and verified sender domain.
- Optional Meta Business/Pixel and optional GA4 properties.
- Business, tax, privacy, and consumer-policy details needed to replace legal placeholders.
