#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
cd "$(dirname "$0")"
command -v pkg >/dev/null 2>&1 || { echo 'Run this script inside Termux on Android.'; exit 1; }
if ! command -v node >/dev/null 2>&1; then
  echo 'Installing Node.js and Git through Termux...'
  pkg update -y
  pkg install -y nodejs-lts git
fi
command -v npm >/dev/null 2>&1 || { echo 'npm was not found. Try: pkg install nodejs-lts'; exit 1; }
if [ ! -f .env.local ]; then cp .env.example .env.local; echo 'Created .env.local. Edit it if you have a PostgreSQL database and secrets configured.'; fi
if [ ! -x node_modules/.bin/next ] || [ ! -d node_modules/pg ]; then
  npm install
fi
# Android/ARM64 has no usable native SWC binary in this Termux setup. Install the
# WASM compiler matching Next.js; Next 15's loader tries WASM first on Android.
NEXT_VERSION="$(node -p "require('next/package.json').version")"
if ! node -e "require.resolve('@next/swc-wasm-nodejs')" >/dev/null 2>&1; then
  npm install --no-save "@next/swc-wasm-nodejs@$NEXT_VERSION"
fi

printf '
EBOORA dev server starting. Open http://127.0.0.1:3000 in your phone browser.
Stop with Ctrl+C.

'
npm run dev -- --hostname 0.0.0.0
