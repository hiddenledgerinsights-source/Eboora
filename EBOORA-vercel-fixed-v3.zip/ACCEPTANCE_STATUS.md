# EBOORA acceptance status — Phase 6

Status labels are intentionally conservative. A file existing in the repository is not evidence that the feature works end-to-end.

| Feature | Status | Evidence / next action |
|---|---|---|
| Product/catalog UI, product detail, SEO pages | Implemented but not tested | Run the production build and browser QA. Public catalog still has static/database divergence noted in earlier phase docs. |
| PostgreSQL schema and migrations 0001–0005 | Implemented but not tested against a live database | Apply to a disposable PostgreSQL database and inspect migration/seed output. |
| Pricing and coupon logic | Implemented; tests exist but execution not confirmed | Run `npm test`; add integration tests for concurrent redemption and database constraints. |
| Registration/login/session/admin product actions | Implemented but not tested | Browser-test auth, session expiry, and all protected server actions. |
| Password reset | Implemented but not tested end-to-end | Requires configured, verified email provider. |
| Checkout/order record creation | Implemented but not tested | Checkout is expected to fail closed while the provider adapter remains unconfigured. |
| Cashfree order creation | **Not implemented** | `src/lib/payments/provider.ts` deliberately throws `PaymentNotConfiguredError`. |
| Cashfree webhook signature verification | **Not implemented** | No webhook is trusted; implement with current official docs and sandbox tests. |
| Verified payment fulfillment | Implemented but not tested; blocked by provider stub | Test valid/invalid signatures, amount/currency mismatch, retries, duplicate event and duplicate payment IDs. |
| Private paid-file storage | **Not implemented** | `src/lib/storage/index.ts` is an unconfigured stub; download route should fail closed. |
| Signed download tokens/rules | Implemented; tests exist but execution not confirmed | Run tests and verify the storage adapter and entitlement queries against PostgreSQL. |
| Transactional email | **Not implemented** | `src/lib/email/provider.ts` is an unconfigured stub; queued messages are not proof of delivery. |
| Meta Pixel browser events and consent banner | Implemented but not tested | Configure a real Pixel ID and verify in Meta Events Manager Test Events. Purchase browser event is not a server-verified CAPI event. |
| Meta Conversions API | **Not implemented** | Requires token/business configuration, consent/legal review, event ID deduplication and tests. |
| GA4 and UTM capture | Implemented but not tested | Configure a measurement ID; verify consent gating and events in GA DebugView. |
| Admin coupons/reviews/analytics | Implemented but not tested | Verify admin authorization and queries with seeded data. |
| Customer account/download history | Implemented but not tested | Test cross-customer isolation and downloads after payment fulfillment. |
| Baseline security headers | Implemented but not tested in a running server | Inspect production responses; adapt CSP and HSTS for actual integrations/domain. |
| Health endpoint | Implemented but not tested against PostgreSQL | `GET /api/health`; expected 200 with DB connectivity, 503 otherwise. |
| Automated tests | Present; **not confirmed executed** | Dependency installation timed out in this environment, so tests/build could not be run here. |
| Production deployment / live payment / real email / real file delivery | **Not performed** | Requires external accounts, credentials, provider adapters, approvals and end-to-end tests. |

## Current launch decision

**Do not launch live payments or advertise automatic delivery yet.** The project can be used for development and architecture review, but critical commerce integrations are intentionally incomplete. The highest-priority work is: (1) complete Cashfree adapter, (2) implement private object storage, (3) implement email provider, (4) add integration tests against disposable PostgreSQL and Cashfree sandbox, (5) complete production build/browser QA, (6) review legal pages and consent behavior.


## Security review notes (2026-10-26)

- Upgraded the Next.js dependency to the patched 15.5.28 maintenance release and React to 19.2.9. Confirm dependency resolution with `npm audit` after installing from the registry.
- Payment fulfillment now rejects a provider payment ID that is already associated with a different order, amount, or currency. This path needs database integration testing.
- Password-reset token creation is capped at five requests per account per hour and expired tokens are periodically cleaned during reset requests.
- This archive was not built or tested against a live PostgreSQL instance in this environment; the package registry was unreachable during the attempted dependency install. Treat the code as a development candidate, not a production security certification.


## Follow-up patch (2026-10-26)
- Database pool now accepts `DATABASE_URL` or Wasmer-style individual PostgreSQL variables and has finite connection/idle timeouts. Credentials are not logged.
- Fixed the mobile header's primary link contrast and added mobile wrapping rules.
- Restored user zoom support for accessibility (maximum scale 5).
- These source changes have not been compiled or tested against a live Wasmer deployment or PostgreSQL instance in this environment. Payment, private storage, and email provider adapters remain intentionally unimplemented and must be completed before production commerce.


## Recheck patch (2026-10-26)
- Updated Next.js request-cookie access to the asynchronous `cookies()` API in session handling and consent checks, including all call sites in the root layout, product page, and analytics route. This addresses a Next.js 15 runtime/API compatibility issue found during source review.
- Termux startup now checks for the actual Next.js and PostgreSQL package directories rather than assuming any existing `node_modules` directory is complete.
- Validation limitation: dependency installation timed out in this environment, so TypeScript compilation, Vitest, and production build remain unverified. The payment, private storage, and transactional email adapters are still deliberately unimplemented; this archive is not production-ready for real commerce.
