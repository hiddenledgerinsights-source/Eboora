// Pure pricing logic. All amounts are integer paise (INR minor units).
// The server must call this; the client's totals are never trusted.

export type Coupon = {
  discountType: "percent" | "fixed";
  discountValue: number;
  minOrderPaise: number;
  productId: string | null;
  expiresAt: Date | null;
  isActive: boolean;
};

export type PricingResult =
  | { ok: true; subtotalPaise: number; discountPaise: number; totalPaise: number }
  | { ok: false; reason: "coupon_inactive" | "coupon_expired" | "coupon_wrong_product" | "coupon_min_order" };

export function discountFor(subtotalPaise: number, coupon: Coupon): number {
  const raw =
    coupon.discountType === "percent"
      ? Math.floor((subtotalPaise * coupon.discountValue) / 100)
      : coupon.discountValue;
  return Math.min(Math.max(raw, 0), subtotalPaise);
}

export function priceOrder(input: {
  productId: string;
  salePricePaise: number;
  coupon?: Coupon | null;
  now?: Date;
}): PricingResult {
  const subtotal = input.salePricePaise;
  if (!input.coupon) {
    return { ok: true, subtotalPaise: subtotal, discountPaise: 0, totalPaise: subtotal };
  }
  const c = input.coupon;
  const now = input.now ?? new Date();
  if (!c.isActive) return { ok: false, reason: "coupon_inactive" };
  if (c.expiresAt && c.expiresAt.getTime() <= now.getTime()) return { ok: false, reason: "coupon_expired" };
  if (c.productId !== null && c.productId !== input.productId) return { ok: false, reason: "coupon_wrong_product" };
  if (subtotal < c.minOrderPaise) return { ok: false, reason: "coupon_min_order" };
  const discount = discountFor(subtotal, c);
  return { ok: true, subtotalPaise: subtotal, discountPaise: discount, totalPaise: subtotal - discount };
}

export function formatINR(paise: number): string {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 })
    .format(paise / 100);
}
