export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const PRODUCT_STATUSES = ["draft", "published", "archived"] as const;
export type ProductStatus = (typeof PRODUCT_STATUSES)[number];

export function validateEmail(email: string): boolean {
  return email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function validatePassword(password: string): string | null {
  if (password.length < 10) return "Password must be at least 10 characters.";
  if (password.length > 256) return "Password is too long.";
  return null;
}

export type ProductValue = {
  title: string;
  slug: string;
  shortDescription: string;
  longDescription: string;
  categoryId: string | null;
  originalPricePaise: number;
  salePricePaise: number;
  status: ProductStatus;
  seoTitle: string | null;
  seoDescription: string | null;
};

const fail = (error: string) => ({ ok: false as const, error });

// Admin enters rupees (e.g. "199.50"); stored as integer paise. Capped at ₹1,00,000.
function toPaise(raw: string): number | null {
  if (!/^\d+(\.\d{1,2})?$/.test(raw)) return null;
  const paise = Math.round(Number(raw) * 100);
  return paise > 0 && paise <= 10_000_000 ? paise : null;
}

export function validateProduct(
  form: FormData
): { ok: true; value: ProductValue } | { ok: false; error: string } {
  const get = (k: string) => String(form.get(k) ?? "").trim();
  const title = get("title");
  const slug = get("slug").toLowerCase();
  const status = get("status");
  const categoryId = get("categoryId") || null;
  const shortDescription = get("shortDescription");
  const longDescription = get("longDescription");

  if (!title || title.length > 200) return fail("Title is required (max 200 characters).");
  if (!/^[a-z0-9-]{3,120}$/.test(slug)) return fail("Slug must be 3–120 lowercase letters, numbers, or hyphens.");
  if (!(PRODUCT_STATUSES as readonly string[]).includes(status)) return fail("Choose a valid status.");
  if (categoryId && !UUID_RE.test(categoryId)) return fail("Choose a valid category.");
  if (shortDescription.length > 300) return fail("Short description must be 300 characters or fewer.");
  if (status === "published" && (!shortDescription || !longDescription)) {
    return fail("Add a short and a long description before publishing.");
  }

  const original = toPaise(get("originalPrice"));
  const sale = toPaise(get("salePrice"));
  if (original === null || sale === null) return fail("Enter valid prices in rupees, e.g. 299 or 199.50.");
  if (sale > original) return fail("Sale price cannot be higher than the original price.");

  return {
    ok: true,
    value: {
      title,
      slug,
      shortDescription,
      longDescription,
      categoryId,
      originalPricePaise: original,
      salePricePaise: sale,
      status: status as ProductStatus,
      seoTitle: get("seoTitle") || null,
      seoDescription: get("seoDescription") || null,
    },
  };
}
