import { randomBytes } from "node:crypto";
import { pool } from "@/lib/db";
import { priceOrder, type Coupon } from "@/lib/pricing";
import { getPaymentProvider, PaymentNotConfiguredError } from "@/lib/payments/provider";

export type CheckoutResult = { ok: true; url: string } | { ok: false; error: string };

const COUPON_ERRORS = {
  coupon_inactive: "This coupon is not active.",
  coupon_expired: "This coupon has expired.",
  coupon_wrong_product: "This coupon does not apply to this product.",
  coupon_min_order: "Your order is below this coupon's minimum amount.",
} as const;

const fail = (error: string): CheckoutResult => ({ ok: false, error });

// Server-side checkout: reads the price from the database, applies the coupon, creates a
// pending order, then asks the provider for a payment session. Nothing here marks an order paid.
export async function createCheckout(input: {
  slug: string;
  email: string;
  couponCode: string;
  userId: string | null;
  siteUrl: string;
}): Promise<CheckoutResult> {
  const client = await pool.connect();
  let orderId = "";
  let ref = "";
  let total = 0;
  try {
    await client.query("BEGIN");
    const bail = async (msg: string) => {
      await client.query("ROLLBACK");
      return fail(msg);
    };

    const { rows: [product] } = await client.query(
      "SELECT id, sale_price_paise FROM products WHERE slug = $1 AND status = 'published'",
      [input.slug]
    );
    if (!product) return bail("This product is not available.");

    let coupon: Coupon | null = null;
    let couponId: string | null = null;
    const code = input.couponCode.trim().toUpperCase();
    if (code) {
      // Lock the coupon row so concurrent checkouts cannot exceed max_redemptions.
      const { rows: [c] } = await client.query(
        `SELECT id, discount_type, discount_value, min_order_paise, product_id, max_redemptions, expires_at, is_active
           FROM coupons WHERE code = $1 FOR UPDATE`,
        [code]
      );
      if (!c) return bail("Coupon not found.");
      if (c.max_redemptions !== null) {
        const { rows: [u] } = await client.query(
          "SELECT count(*)::int AS n FROM orders WHERE coupon_id = $1 AND status IN ('pending','paid')",
          [c.id]
        );
        if (u.n >= c.max_redemptions) return bail("This coupon has been fully used.");
      }
      coupon = {
        discountType: c.discount_type,
        discountValue: c.discount_value,
        minOrderPaise: c.min_order_paise,
        productId: c.product_id,
        expiresAt: c.expires_at,
        isActive: c.is_active,
      };
      couponId = c.id;
    }

    const priced = priceOrder({ productId: product.id, salePricePaise: product.sale_price_paise, coupon });
    if (!priced.ok) return bail(COUPON_ERRORS[priced.reason]);
    if (priced.totalPaise < 100) return bail("Orders below ₹1 are not supported.");

    ref = "EB-" + randomBytes(9).toString("base64url");
    const { rows: [o] } = await client.query(
      `INSERT INTO orders (public_order_ref, user_id, customer_email, subtotal_paise, discount_paise, total_paise, currency, coupon_id)
       VALUES ($1, $2, $3, $4, $5, $6, 'INR', $7) RETURNING id`,
      [ref, input.userId, input.email, priced.subtotalPaise, priced.discountPaise, priced.totalPaise, couponId]
    );
    orderId = o.id;
    await client.query(
      "INSERT INTO order_items (order_id, product_id, unit_price_paise) VALUES ($1, $2, $3)",
      [orderId, product.id, priced.subtotalPaise]
    );
    await client.query("COMMIT");
    total = priced.totalPaise;
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }

  try {
    const po = await getPaymentProvider().createOrder({
      publicOrderRef: ref,
      amountPaise: total,
      currency: "INR",
      customerEmail: input.email,
      returnUrl: `${input.siteUrl}/orders/${ref}`,
    });
    await pool.query(
      "INSERT INTO payment_attempts (order_id, provider_order_id, status) VALUES ($1, $2, 'created')",
      [orderId, po.providerOrderId]
    );
    return { ok: true, url: po.paymentUrl };
  } catch (e) {
    await pool.query("UPDATE orders SET status = 'failed' WHERE id = $1 AND status = 'pending'", [orderId]);
    if (e instanceof PaymentNotConfiguredError) return fail("Online payment is not available yet.");
    console.error("checkout: provider order creation failed for", ref);
    return fail("Payment could not be started. Please try again.");
  }
}
