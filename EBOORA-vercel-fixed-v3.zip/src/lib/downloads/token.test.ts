import { describe, it, expect } from "vitest";
import { signGrantToken, verifyGrantToken } from "./token";

const SECRET = "x".repeat(40);
const ID = "3f2504e0-4f89-41d3-9a0c-0305e82c3301";
const NOW = 1_700_000_000_000;

describe("grant tokens", () => {
  it("verifies a fresh token", () => {
    const t = signGrantToken(ID, NOW + 60_000, SECRET);
    expect(verifyGrantToken(t, SECRET, NOW)).toEqual({ grantId: ID, expiresAtMs: NOW + 60_000 });
  });
  it("rejects an expired token", () => {
    const t = signGrantToken(ID, NOW - 1, SECRET);
    expect(verifyGrantToken(t, SECRET, NOW)).toBeNull();
  });
  it("rejects a token signed with another secret", () => {
    const t = signGrantToken(ID, NOW + 60_000, "y".repeat(40));
    expect(verifyGrantToken(t, SECRET, NOW)).toBeNull();
  });
  it("rejects a tampered grant id", () => {
    const t = signGrantToken(ID, NOW + 60_000, SECRET);
    const [, sig] = t.split(".");
    const forged = Buffer.from(`00000000-0000-4000-8000-000000000000.${NOW + 60_000}`).toString("base64url");
    expect(verifyGrantToken(`${forged}.${sig}`, SECRET, NOW)).toBeNull();
  });
  it("rejects a tampered expiry", () => {
    const t = signGrantToken(ID, NOW + 60_000, SECRET);
    const [, sig] = t.split(".");
    const forged = Buffer.from(`${ID}.${NOW + 9_000_000_000}`).toString("base64url");
    expect(verifyGrantToken(`${forged}.${sig}`, SECRET, NOW)).toBeNull();
  });
  it("rejects malformed input", () => {
    expect(verifyGrantToken("garbage", SECRET, NOW)).toBeNull();
    expect(verifyGrantToken("a.b.c", SECRET, NOW)).toBeNull();
  });
});
