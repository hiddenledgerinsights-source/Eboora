import { pool } from "@/lib/db";
import { getPrivateStorage, StorageNotConfiguredError } from "@/lib/storage";
import { grantUnusableReason, RATE_LIMIT_PER_MINUTE } from "./rules";

const MESSAGES = {
  order_not_paid: "This download is not available.",
  grant_expired: "This download has expired.",
  limit_reached: "You have used all downloads for this file. Contact support if you need more.",
} as const;

const text = (body: string, status: number) =>
  new Response(body, { status, headers: { "Cache-Control": "no-store" } });

function safeFileName(name: string): string {
  return name.replace(/[^A-Za-z0-9._-]/g, "_").slice(0, 150) || "download";
}

// Reserves one download in a transaction, then streams the file.
// Grants point at a specific file version, so replacing a product file never changes
// files already bought. Old storage objects must not be deleted while grants reference them.
export async function serveGrant(grantId: string): Promise<Response> {
  const client = await pool.connect();
  let logId = 0;
  let row: {
    storage_key: string; file_name: string; mime_type: string;
    max_downloads: number; downloads_used: number; expires_at: Date | null; order_status: string;
  };
  try {
    await client.query("BEGIN");
    const { rows: [recent] } = await client.query(
      "SELECT count(*)::int AS n FROM download_logs WHERE grant_id = $1 AND created_at > now() - interval '1 minute'",
      [grantId]
    );
    if (recent.n >= RATE_LIMIT_PER_MINUTE) {
      await client.query("ROLLBACK");
      return text("Too many download attempts. Wait a minute and try again.", 429);
    }

    const { rows: [g] } = await client.query(
      `SELECT pf.storage_key, pf.file_name, pf.mime_type, dg.max_downloads, dg.downloads_used,
              dg.expires_at, o.status AS order_status
         FROM download_grants dg
         JOIN orders o ON o.id = dg.order_id
         JOIN product_files pf ON pf.id = dg.product_file_id
        WHERE dg.id = $1
        FOR UPDATE OF dg`,
      [grantId]
    );
    if (!g) {
      await client.query("ROLLBACK");
      return text("This download is not available.", 404);
    }
    row = g;

    const reason = grantUnusableReason(row, new Date());
    if (reason) {
      await client.query("ROLLBACK");
      return text(MESSAGES[reason], 403);
    }

    await client.query("UPDATE download_grants SET downloads_used = downloads_used + 1 WHERE id = $1", [grantId]);
    const { rows: [log] } = await client.query(
      "INSERT INTO download_logs (grant_id, succeeded) VALUES ($1, false) RETURNING id",
      [grantId]
    );
    logId = log.id;
    await client.query("COMMIT");
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }

  try {
    const stream = await getPrivateStorage().openStream(row.storage_key);
    await pool.query("UPDATE download_logs SET succeeded = true WHERE id = $1", [logId]);
    const headers: Record<string, string> = {
      "Content-Type": row.mime_type,
      "Content-Disposition": `attachment; filename="${safeFileName(row.file_name)}"`,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    };
    if (stream.size !== null) headers["Content-Length"] = String(stream.size);
    return new Response(stream.body, { headers });
  } catch (e) {
    // Give the download back so a storage outage does not use up the customer's allowance.
    await pool.query("UPDATE download_grants SET downloads_used = GREATEST(downloads_used - 1, 0) WHERE id = $1", [grantId]);
    if (e instanceof StorageNotConfiguredError) return text("Downloads are not available yet. Please try again later.", 503);
    console.error("download: storage read failed for grant", grantId);
    return text("The file could not be delivered. Please try again.", 500);
  }
}
