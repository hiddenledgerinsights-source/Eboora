import { createHmac, timingSafeEqual } from "node:crypto";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Requires a 32+ character secret. Throws if missing so downloads fail closed.
export function getDownloadSecret(): string {
  const s = process.env.DOWNLOAD_SIGNING_SECRET ?? "";
  if (s.length < 32) throw new Error("DOWNLOAD_SIGNING_SECRET must be set (32+ characters)");
  return s;
}

const mac = (payload: string, secret: string) =>
  createHmac("sha256", secret).update(payload).digest("base64url");

// Token = base64url("<grantId>.<expiresAtMs>") + "." + HMAC. Only links signed with our secret work.
export function signGrantToken(grantId: string, expiresAtMs: number, secret: string): string {
  const payload = `${grantId}.${expiresAtMs}`;
  return `${Buffer.from(payload).toString("base64url")}.${mac(payload, secret)}`;
}

export function verifyGrantToken(
  token: string,
  secret: string,
  nowMs: number
): { grantId: string; expiresAtMs: number } | null {
  const [encoded, sig, extra] = token.split(".");
  if (!encoded || !sig || extra !== undefined) return null;
  const payload = Buffer.from(encoded, "base64url").toString("utf8");
  const expected = Buffer.from(mac(payload, secret));
  const given = Buffer.from(sig);
  if (expected.length !== given.length || !timingSafeEqual(expected, given)) return null;

  const [grantId, expStr] = payload.split(".");
  const expiresAtMs = Number(expStr);
  if (!UUID_RE.test(grantId) || !Number.isFinite(expiresAtMs) || expiresAtMs <= nowMs) return null;
  return { grantId, expiresAtMs };
}
