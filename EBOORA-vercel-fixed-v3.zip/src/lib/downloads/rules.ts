// Pure download rules. No imports, so they can be unit tested without a database.
export type GrantState = {
  max_downloads: number;
  downloads_used: number;
  expires_at: Date | null;
  order_status: string;
};

export type UnusableReason = "order_not_paid" | "grant_expired" | "limit_reached";

export const RATE_LIMIT_PER_MINUTE = 10;

export function grantUnusableReason(g: GrantState, now: Date): UnusableReason | null {
  if (g.order_status !== "paid") return "order_not_paid";
  if (g.expires_at && g.expires_at.getTime() <= now.getTime()) return "grant_expired";
  if (g.downloads_used >= g.max_downloads) return "limit_reached";
  return null;
}
