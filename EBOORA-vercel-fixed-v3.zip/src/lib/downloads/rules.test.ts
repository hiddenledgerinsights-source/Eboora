import { describe, it, expect } from "vitest";
import { grantUnusableReason } from "./rules";

const now = new Date("2026-10-26T10:00:00Z");
const ok = { max_downloads: 5, downloads_used: 0, expires_at: null, order_status: "paid" };

describe("grantUnusableReason", () => {
  it("allows a paid, unexpired grant with downloads left", () => {
    expect(grantUnusableReason(ok, now)).toBeNull();
  });
  it("blocks unpaid orders", () => {
    expect(grantUnusableReason({ ...ok, order_status: "pending" }, now)).toBe("order_not_paid");
  });
  it("blocks expired grants", () => {
    expect(grantUnusableReason({ ...ok, expires_at: new Date("2026-01-01") }, now)).toBe("grant_expired");
  });
  it("blocks grants that used all downloads", () => {
    expect(grantUnusableReason({ ...ok, downloads_used: 5 }, now)).toBe("limit_reached");
  });
});
