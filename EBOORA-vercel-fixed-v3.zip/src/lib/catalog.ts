// Read-only catalog access. Phase 1 uses a static fallback; swap for a DB query
// (db/seed.sql provides the same rows) once DATABASE_URL is configured.
export type PublicProduct = {
  slug: string;
  title: string;
  shortDescription: string;
  longDescription: string;
  category: string;
  originalPricePaise: number;
  salePricePaise: number;
  seoTitle: string;
  seoDescription: string;
};

export const PRODUCTS: PublicProduct[] = [
  {
    slug: "home-workout-30-day-fitness-bundle",
    title: "Best Home Workout to Be Fit — 30-Day Fitness Bundle",
    shortDescription: "A 30-day home workout plan you can follow with no equipment.",
    longDescription: "A beginner-friendly 30-day structure for building a home movement routine. Review the plan at your own pace, adapt activity to your current ability, and take rest days when needed. This listing is a development placeholder; add and verify the final PDF/ZIP files and their contents before accepting payment.",
    category: "Fitness",
    originalPricePaise: 29900,
    salePricePaise: 19900,
    seoTitle: "Home Workout 30-Day Fitness Bundle | EBOORA",
    seoDescription: "A 30-day home workout bundle (PDF and ZIP) for beginners. No equipment needed.",
  },
];

export function getProductBySlug(slug: string): PublicProduct | undefined {
  return PRODUCTS.find((p) => p.slug === slug);
}
