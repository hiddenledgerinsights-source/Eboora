import { pool } from "./db";

export async function audit(actorId: string | null, action: string, target: string | null): Promise<void> {
  await pool.query("INSERT INTO audit_logs (actor_id, action, target) VALUES ($1, $2, $3)", [
    actorId,
    action,
    target,
  ]);
}
