import { createHash, randomBytes } from "node:crypto";
import { pool } from "@/lib/db";
import { hashPassword } from "@/lib/password";
import { getEmailProvider } from "@/lib/email/provider";
import { passwordReset } from "@/lib/email/templates";

const sha256 = (s: string) => createHash("sha256").update(s).digest("hex");
const siteUrl = () => process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

// Always returns normally, whether or not the account exists, so the response does not reveal accounts.
export async function requestPasswordReset(email: string): Promise<void> {
  const { rows: [u] } = await pool.query("SELECT id, email FROM users WHERE email = $1", [email]);
  if (!u) return;

  // Bound reset-email abuse per account. The public action always returns the same message.
  const { rows: [recent] } = await pool.query(
    "SELECT count(*)::int AS n FROM password_reset_tokens WHERE user_id = $1 AND created_at > now() - interval '1 hour'",
    [u.id]
  );
  if (recent.n >= 5) return;
  await pool.query("DELETE FROM password_reset_tokens WHERE expires_at < now() - interval '1 day'");

  const token = randomBytes(32).toString("base64url");
  await pool.query(
    "INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES ($1, $2, now() + interval '1 hour')",
    [u.id, sha256(token)]
  );
  const link = `${siteUrl()}/reset-password?token=${token}`;
  try {
    await getEmailProvider().send({ to: u.email, ...passwordReset(link) });
  } catch {
    // Email is not configured yet. The token still exists and will expire in an hour.
    console.error("password reset: email not sent (provider not configured or failed)");
  }
}

// Single-use token. On success, changes the password and signs the user out everywhere.
export async function resetPassword(
  token: string,
  newPassword: string
): Promise<{ ok: true } | { ok: false; error: string }> {
  const newHash = await hashPassword(newPassword);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows: [t] } = await client.query(
      "SELECT id, user_id FROM password_reset_tokens WHERE token_hash = $1 AND used_at IS NULL AND expires_at > now() FOR UPDATE",
      [sha256(token)]
    );
    if (!t) {
      await client.query("ROLLBACK");
      return { ok: false, error: "This reset link is invalid or has expired." };
    }
    await client.query("UPDATE users SET password_hash = $2 WHERE id = $1", [t.user_id, newHash]);
    await client.query("UPDATE password_reset_tokens SET used_at = now() WHERE user_id = $1 AND used_at IS NULL", [t.user_id]);
    await client.query("DELETE FROM sessions WHERE user_id = $1", [t.user_id]);
    await client.query("COMMIT");
    return { ok: true };
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}
