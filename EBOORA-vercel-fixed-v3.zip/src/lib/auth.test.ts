import { describe, it, expect, vi } from "vitest";

vi.mock("next/navigation", () => ({
  redirect: (path: string) => { throw new Error(`REDIRECT:${path}`); },
}));
vi.mock("./session", () => ({ readSessionUser: vi.fn() }));

import { readSessionUser } from "./session";
import { requireAdmin } from "./auth";

const mocked = vi.mocked(readSessionUser);
const user = (role: "customer" | "admin") => ({ id: "u1", email: "x@y.co", role, full_name: null });

describe("server-side authorization", () => {
  it("redirects anonymous visitors to login", async () => {
    mocked.mockResolvedValueOnce(null);
    await expect(requireAdmin()).rejects.toThrow("REDIRECT:/login");
  });
  it("redirects customers away from admin", async () => {
    mocked.mockResolvedValueOnce(user("customer"));
    await expect(requireAdmin()).rejects.toThrow("REDIRECT:/");
  });
  it("lets admins through", async () => {
    mocked.mockResolvedValueOnce(user("admin"));
    await expect(requireAdmin()).resolves.toMatchObject({ role: "admin" });
  });
});
