import type { PoolClient } from "pg";
import { pool } from "@/lib/db";
import { buildEmail, type Template } from "./build";
import { EmailNotConfiguredError, getEmailProvider, isEmailConfigured } from "./provider";

const MAX_ATTEMPTS = 5;

// Called inside the payment transaction, so the email is queued only if the payment commits.
export async function enqueueOrderEmail(client: PoolClient, orderId: string, template: Template): Promise<void> {
  await client.query(
    `INSERT INTO email_logs (order_id, to_address, template)
     SELECT id, customer_email, $2 FROM orders WHERE id = $1`,
    [orderId, template]
  );
}

export async function sendQueuedEmails(limit = 20): Promise<{ sent: number; failed: number; configured: boolean }> {
  if (!isEmailConfigured()) return { sent: 0, failed: 0, configured: false };

  // Claim rows atomically so concurrent runs do not send the same email twice.
  const { rows: claimed } = await pool.query(
    `UPDATE email_logs SET status = 'sending', attempts = attempts + 1
      WHERE id IN (
        SELECT id FROM email_logs
         WHERE status = 'queued' AND attempts < $2
         ORDER BY created_at
         LIMIT $1
         FOR UPDATE SKIP LOCKED
      )
      RETURNING id, order_id, to_address, template, attempts`,
    [limit, MAX_ATTEMPTS]
  );

  let sent = 0;
  let failed = 0;
  for (const row of claimed) {
    try {
      const msg = await buildEmail(row.template, row.order_id);
      if (!msg) {
        await pool.query("UPDATE email_logs SET status = 'failed', last_error = 'not_eligible' WHERE id = $1", [row.id]);
        failed++;
        continue;
      }
      await getEmailProvider().send({ to: row.to_address, ...msg });
      await pool.query("UPDATE email_logs SET status = 'sent', sent_at = now() WHERE id = $1", [row.id]);
      sent++;
    } catch (e) {
      const next = row.attempts >= MAX_ATTEMPTS ? "failed" : "queued";
      // Store only the error class name, never provider responses that may echo addresses or keys.
      const errName = e instanceof EmailNotConfiguredError ? "not_configured" : (e as Error).name;
      await pool.query("UPDATE email_logs SET status = $2, last_error = $3 WHERE id = $1", [row.id, next, errName]);
      failed++;
    }
  }
  return { sent, failed, configured: true };
}
