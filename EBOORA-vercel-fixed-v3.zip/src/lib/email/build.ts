import { pool } from "@/lib/db";
import { getDownloadSecret, signGrantToken } from "@/lib/downloads/token";
import { orderConfirmation, paymentFailed, type Rendered } from "./templates";

export type Template = "order_confirmation" | "payment_failed";

const TOKEN_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const siteUrl = () => process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

// Builds the email from current database state at send time. Never confirms an unpaid order.
export async function buildEmail(template: Template, orderId: string): Promise<Rendered | null> {
  const { rows: [o] } = await pool.query("SELECT public_order_ref, status FROM orders WHERE id = $1", [orderId]);
  if (!o) return null;

  if (template === "payment_failed") return paymentFailed(o.public_order_ref);
  if (o.status !== "paid") return null;

  const { rows: grants } = await pool.query(
    `SELECT dg.id, pf.file_name, p.title
       FROM download_grants dg
       JOIN product_files pf ON pf.id = dg.product_file_id
       JOIN products p ON p.id = pf.product_id
      WHERE dg.order_id = $1
      ORDER BY p.title, pf.file_name`,
    [orderId]
  );
  const secret = getDownloadSecret();
  const expiresAt = Date.now() + TOKEN_TTL_MS;
  const items = grants.map((g) => ({
    title: `${g.title} (${g.file_name})`,
    url: `${siteUrl()}/api/download/${signGrantToken(g.id, expiresAt, secret)}`,
  }));
  return orderConfirmation({ orderRef: o.public_order_ref, items });
}
