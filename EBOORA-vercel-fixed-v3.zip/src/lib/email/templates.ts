// Plain template functions. No imports, so they can be tested directly.
export type Rendered = { subject: string; text: string; html: string };

export function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

export function orderConfirmation(p: { orderRef: string; items: { title: string; url: string }[] }): Rendered {
  const lines = p.items.map((i) => `- ${i.title}: ${i.url}`).join("\n");
  const li = p.items
    .map((i) => `<li>${escapeHtml(i.title)} &mdash; <a href="${escapeHtml(i.url)}">Download</a></li>`)
    .join("");
  return {
    subject: `Your EBOORA order ${p.orderRef} is confirmed`,
    text:
      `Thanks for your purchase. Order ${p.orderRef} is confirmed.\n\n` +
      `Download links (valid for 30 days, limited number of downloads):\n${lines}\n`,
    html:
      `<p>Thanks for your purchase. Order <strong>${escapeHtml(p.orderRef)}</strong> is confirmed.</p>` +
      `<ul>${li}</ul><p>Links are valid for 30 days with a limited number of downloads.</p>`,
  };
}

export function paymentFailed(orderRef: string): Rendered {
  return {
    subject: "Your EBOORA payment did not go through",
    text: `Payment for order ${orderRef} was not completed. You can return to the product page and try again.\n`,
    html: `<p>Payment for order <strong>${escapeHtml(orderRef)}</strong> was not completed. You can return to the product page and try again.</p>`,
  };
}

export function passwordReset(link: string): Rendered {
  return {
    subject: "Reset your EBOORA password",
    text: `Use this link to set a new password. It expires in 1 hour:\n${link}\n\nIf you did not ask for this, ignore this email.\n`,
    html: `<p>Use this link to set a new password. It expires in 1 hour.</p><p><a href="${escapeHtml(link)}">Reset password</a></p><p>If you did not ask for this, ignore this email.</p>`,
  };
}
