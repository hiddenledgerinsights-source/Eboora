// Transactional email boundary.
//
// STATUS: NOT configured. Choose a provider, add its server-side API key and a verified
// sending domain (SPF, DKIM, and DMARC records), implement send(), and set
// isEmailConfigured() to true only after a real test email arrives.
// Until then no email is sent and queued emails stay queued without using up attempts.

export class EmailNotConfiguredError extends Error {}

export type OutgoingEmail = { to: string; subject: string; text: string; html: string };

export interface EmailProvider {
  send(msg: OutgoingEmail): Promise<{ providerMessageId: string }>;
}

class UnconfiguredEmail implements EmailProvider {
  async send(_msg: OutgoingEmail): Promise<{ providerMessageId: string }> {
    throw new EmailNotConfiguredError("Transactional email provider is not configured or verified.");
  }
}

export function isEmailConfigured(): boolean {
  return false; // TODO: flip only after a real provider is implemented and tested.
}

export function getEmailProvider(): EmailProvider {
  return new UnconfiguredEmail();
}
