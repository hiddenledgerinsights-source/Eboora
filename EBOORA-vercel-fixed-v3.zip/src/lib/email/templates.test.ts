import { describe, it, expect } from "vitest";
import { escapeHtml, orderConfirmation, passwordReset } from "./templates";

describe("email templates", () => {
  it("escapes HTML in product titles", () => {
    const r = orderConfirmation({
      orderRef: "EB-abc",
      items: [{ title: "<script>x</script>", url: "https://example.com/a?b=1&c=2" }],
    });
    expect(r.html).not.toContain("<script>");
    expect(r.html).toContain("&lt;script&gt;");
    expect(r.html).toContain("&amp;c=2");
  });
  it("escapes special characters", () => {
    expect(escapeHtml(`"'<>&`)).toBe("&quot;&#39;&lt;&gt;&amp;");
  });
  it("puts the reset link in both bodies", () => {
    const r = passwordReset("https://example.com/reset-password?token=abc");
    expect(r.text).toContain("token=abc");
    expect(r.html).toContain("token=abc");
  });
});
