// Private object storage boundary. Paid files are only ever read by the server.
//
// STATUS: NOT implemented. Choose a provider (for example Supabase Storage or an
// S3-compatible bucket with private access), create a service-side client from
// server-only credentials, and implement openStream. Until then downloads fail
// closed with 503 and the download counter is rolled back.

export class StorageNotConfiguredError extends Error {}

export interface PrivateStorage {
  openStream(storageKey: string): Promise<{ body: ReadableStream<Uint8Array>; size: number | null }>;
}

class UnconfiguredStorage implements PrivateStorage {
  async openStream(_storageKey: string): Promise<never> {
    throw new StorageNotConfiguredError("Private storage provider is not configured.");
  }
}

export function getPrivateStorage(): PrivateStorage {
  return new UnconfiguredStorage();
}
