import { redirect } from "next/navigation";
import { readSessionUser } from "./session";

export type SessionUser = {
  id: string;
  email: string;
  role: "customer" | "admin";
  full_name: string | null;
};

// Server-side checks. Call these inside every protected page, layout, and server action.
export async function getCurrentUser(): Promise<SessionUser | null> {
  return (await readSessionUser()) as SessionUser | null;
}

export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

export async function requireAdmin(): Promise<SessionUser> {
  const user = await requireUser();
  if (user.role !== "admin") redirect("/");
  return user;
}
