// Structured data built only from real values. aggregateRating appears only when real approved reviews exist.
export function buildProductJsonLd(p: {
  name: string;
  description: string;
  url: string;
  priceRupees: string;
  rating: { value: number; count: number } | null;
}): Record<string, unknown> {
  const out: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: p.name,
    description: p.description,
    url: p.url,
    offers: {
      "@type": "Offer",
      price: p.priceRupees,
      priceCurrency: "INR",
      availability: "https://schema.org/InStock",
      url: p.url,
    },
  };
  if (p.rating && p.rating.count > 0) {
    out.aggregateRating = {
      "@type": "AggregateRating",
      ratingValue: p.rating.value.toFixed(1),
      reviewCount: p.rating.count,
    };
  }
  return out;
}

// Escapes "<" so the JSON cannot close its script tag.
export function safeJsonLd(obj: unknown): string {
  return JSON.stringify(obj).replace(/</g, "\\u003c");
}
