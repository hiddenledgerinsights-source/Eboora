import { describe, it, expect } from "vitest";
import { validateCoupon, rupeesToPaise } from "./coupon-validation";

const base: Record<string, string> = {
  code: "save10", discountType: "percent", discountValue: "10", minOrder: "", productId: "",
  maxRedemptions: "", expiresOn: "",
};
const form = (o: Record<string, string> = {}) => {
  const f = new FormData();
  for (const [k, v] of Object.entries({ ...base, ...o })) f.set(k, v);
  return f;
};

describe("validateCoupon", () => {
  it("uppercases the code and accepts a percent coupon", () => {
    const r = validateCoupon(form());
    expect(r.ok && r.value.code).toBe("SAVE10");
    expect(r.ok && r.value.discountValue).toBe(10);
  });
  it("converts a fixed rupee amount to paise", () => {
    const r = validateCoupon(form({ discountType: "fixed", discountValue: "50" }));
    expect(r.ok && r.value.discountValue).toBe(5000);
  });
  it("rejects percent above 100", () => {
    expect(validateCoupon(form({ discountValue: "150" })).ok).toBe(false);
  });
  it("rejects bad codes", () => {
    expect(validateCoupon(form({ code: "a b" })).ok).toBe(false);
  });
  it("sets expiry at end of day IST", () => {
    const r = validateCoupon(form({ expiresOn: "2026-12-31" }));
    expect(r.ok && r.value.expiresAt).toBe("2026-12-31T23:59:59+05:30");
  });
  it("rejects a malformed expiry", () => {
    expect(validateCoupon(form({ expiresOn: "31/12/2026" })).ok).toBe(false);
  });
  it("rejects a zero max redemption", () => {
    expect(validateCoupon(form({ maxRedemptions: "0" })).ok).toBe(false);
  });
});

describe("rupeesToPaise", () => {
  it("handles decimals and rejects junk", () => {
    expect(rupeesToPaise("199.50")).toBe(19950);
    expect(rupeesToPaise("1.999")).toBeNull();
    expect(rupeesToPaise("abc")).toBeNull();
  });
});
