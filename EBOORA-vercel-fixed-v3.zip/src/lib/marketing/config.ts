// IDs are public (they appear in page source), so they live in NEXT_PUBLIC_ variables.
// Invalid values are ignored, so a typo never injects arbitrary script.
export function metaPixelId(): string | null {
  const v = process.env.NEXT_PUBLIC_META_PIXEL_ID ?? "";
  return /^\d{5,20}$/.test(v) ? v : null;
}
export function gaMeasurementId(): string | null {
  const v = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID ?? "";
  return /^G-[A-Z0-9]{4,20}$/.test(v) ? v : null;
}
