import { UUID_RE } from "@/lib/validation";

export type CouponValue = {
  code: string;
  discountType: "percent" | "fixed";
  discountValue: number;
  minOrderPaise: number;
  productId: string | null;
  maxRedemptions: number | null;
  expiresAt: string | null;
};

const fail = (error: string) => ({ ok: false as const, error });

// Rupees (e.g. "50" or "99.50") to paise. Null when the format or range is invalid.
export function rupeesToPaise(raw: string): number | null {
  if (!/^\d+(\.\d{1,2})?$/.test(raw)) return null;
  const paise = Math.round(Number(raw) * 100);
  return paise >= 0 && paise <= 10_000_000 ? paise : null;
}

export function validateCoupon(
  form: FormData
): { ok: true; value: CouponValue } | { ok: false; error: string } {
  const get = (k: string) => String(form.get(k) ?? "").trim();
  const code = get("code").toUpperCase();
  if (!/^[A-Z0-9]{3,20}$/.test(code)) return fail("Code must be 3–20 letters or numbers.");

  const discountType = get("discountType");
  if (discountType !== "percent" && discountType !== "fixed") return fail("Choose percent or fixed.");

  const rawValue = get("discountValue");
  let discountValue: number;
  if (discountType === "percent") {
    if (!/^\d{1,3}$/.test(rawValue) || Number(rawValue) < 1 || Number(rawValue) > 100) {
      return fail("Percent must be a whole number from 1 to 100.");
    }
    discountValue = Number(rawValue);
  } else {
    const paise = rupeesToPaise(rawValue);
    if (paise === null || paise <= 0) return fail("Enter a valid fixed amount in rupees.");
    discountValue = paise;
  }

  const minOrderPaise = rupeesToPaise(get("minOrder") || "0");
  if (minOrderPaise === null) return fail("Minimum order must be a valid amount in rupees.");

  const productId = get("productId") || null;
  if (productId && !UUID_RE.test(productId)) return fail("Choose a valid product.");

  const maxRaw = get("maxRedemptions");
  let maxRedemptions: number | null = null;
  if (maxRaw) {
    if (!/^\d{1,6}$/.test(maxRaw) || Number(maxRaw) < 1) return fail("Max redemptions must be a positive number.");
    maxRedemptions = Number(maxRaw);
  }

  const expiresOn = get("expiresOn");
  let expiresAt: string | null = null;
  if (expiresOn) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(expiresOn) || Number.isNaN(Date.parse(expiresOn))) {
      return fail("Expiry must be a valid date.");
    }
    // End of that day in IST (the store's timezone).
    expiresAt = `${expiresOn}T23:59:59+05:30`;
  }

  return {
    ok: true,
    value: { code, discountType, discountValue, minOrderPaise, productId, maxRedemptions, expiresAt },
  };
}
