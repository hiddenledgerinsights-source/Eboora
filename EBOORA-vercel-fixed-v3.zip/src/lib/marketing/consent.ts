import { cookies } from "next/headers";

export const CONSENT_COOKIE = "eb_consent";

export async function consentState(): Promise<"granted" | "denied" | null> {
  const v = (await cookies()).get(CONSENT_COOKIE)?.value;
  return v === "granted" || v === "denied" ? v : null;
}

// Pixels, GA, and first-party analytics only run after explicit consent.
export async function hasAnalyticsConsent(): Promise<boolean> {
  return (await consentState()) === "granted";
}
