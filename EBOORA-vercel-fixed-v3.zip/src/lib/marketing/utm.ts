// Accepts only short, plain tokens for UTM values. Anything else is dropped.
export function sanitizeUtm(v: unknown): string | null {
  if (typeof v !== "string") return null;
  const t = v.trim().slice(0, 100);
  return /^[A-Za-z0-9 _.+-]{1,100}$/.test(t) ? t : null;
}
