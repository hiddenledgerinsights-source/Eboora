// Browser-only helper. Does nothing unless the Meta Pixel has loaded (i.e. consent was granted).
type Fbq = (...args: unknown[]) => void;

export function trackPixel(name: string, params: Record<string, unknown>, eventId?: string): void {
  const fbq = (window as unknown as { fbq?: Fbq }).fbq;
  if (typeof fbq !== "function") return;
  if (eventId) fbq("track", name, params, { eventID: eventId });
  else fbq("track", name, params);
}
