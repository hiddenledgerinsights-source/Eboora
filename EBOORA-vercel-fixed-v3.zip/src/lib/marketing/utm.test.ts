import { describe, it, expect } from "vitest";
import { sanitizeUtm } from "./utm";

describe("sanitizeUtm", () => {
  it("keeps plain tokens", () => {
    expect(sanitizeUtm("facebook")).toBe("facebook");
    expect(sanitizeUtm("diwali_sale-2026")).toBe("diwali_sale-2026");
  });
  it("drops markup and non-strings", () => {
    expect(sanitizeUtm("<script>")).toBeNull();
    expect(sanitizeUtm(42)).toBeNull();
    expect(sanitizeUtm("   ")).toBeNull();
  });
});
