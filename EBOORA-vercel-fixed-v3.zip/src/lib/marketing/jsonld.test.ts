import { describe, it, expect } from "vitest";
import { buildProductJsonLd, safeJsonLd } from "./jsonld";

const base = { name: "Bundle", description: "d", url: "https://x.test/p/a", priceRupees: "199.00" };

describe("product structured data", () => {
  it("omits aggregateRating when there are no approved reviews", () => {
    const j = buildProductJsonLd({ ...base, rating: null });
    expect(j).not.toHaveProperty("aggregateRating");
    expect(j).toMatchObject({ "@type": "Product", offers: { priceCurrency: "INR", price: "199.00" } });
  });
  it("includes aggregateRating when reviews exist", () => {
    const j = buildProductJsonLd({ ...base, rating: { value: 4.5, count: 2 } });
    expect(j).toHaveProperty("aggregateRating.reviewCount", 2);
  });
  it("escapes < in serialized JSON-LD", () => {
    expect(safeJsonLd({ name: "</script>" })).not.toContain("</script>");
  });
});
