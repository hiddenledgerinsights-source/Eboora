import { describe, it, expect } from "vitest";
import { priceOrder, discountFor, formatINR, type Coupon } from "./pricing";

const base: Coupon = {
  discountType: "percent", discountValue: 10, minOrderPaise: 0,
  productId: null, expiresAt: null, isActive: true,
};

describe("priceOrder", () => {
  it("returns sale price with no coupon", () => {
    const r = priceOrder({ productId: "p1", salePricePaise: 19900 });
    expect(r).toEqual({ ok: true, subtotalPaise: 19900, discountPaise: 0, totalPaise: 19900 });
  });
  it("applies a 10% percent coupon with floor rounding", () => {
    const r = priceOrder({ productId: "p1", salePricePaise: 19901, coupon: base });
    expect(r).toEqual({ ok: true, subtotalPaise: 19901, discountPaise: 1990, totalPaise: 17911 });
  });
  it("applies a fixed coupon and never goes below zero", () => {
    const c: Coupon = { ...base, discountType: "fixed", discountValue: 50000 };
    const r = priceOrder({ productId: "p1", salePricePaise: 19900, coupon: c });
    expect(r).toMatchObject({ ok: true, discountPaise: 19900, totalPaise: 0 });
  });
  it("rejects expired coupons", () => {
    const c: Coupon = { ...base, expiresAt: new Date("2020-01-01") };
    expect(priceOrder({ productId: "p1", salePricePaise: 19900, coupon: c, now: new Date("2026-01-01") }))
      .toEqual({ ok: false, reason: "coupon_expired" });
  });
  it("rejects inactive coupons", () => {
    expect(priceOrder({ productId: "p1", salePricePaise: 19900, coupon: { ...base, isActive: false } }))
      .toEqual({ ok: false, reason: "coupon_inactive" });
  });
  it("rejects product-restricted coupons for other products", () => {
    expect(priceOrder({ productId: "p2", salePricePaise: 19900, coupon: { ...base, productId: "p1" } }))
      .toEqual({ ok: false, reason: "coupon_wrong_product" });
  });
  it("enforces minimum order value", () => {
    expect(priceOrder({ productId: "p1", salePricePaise: 19900, coupon: { ...base, minOrderPaise: 50000 } }))
      .toEqual({ ok: false, reason: "coupon_min_order" });
  });
});

describe("discountFor", () => {
  it("caps percent discount at 100% of subtotal", () => {
    expect(discountFor(1000, { ...base, discountValue: 100 })).toBe(1000);
  });
});

describe("formatINR", () => {
  it("formats paise as rupees", () => {
    expect(formatINR(19900)).toContain("199");
  });
});
