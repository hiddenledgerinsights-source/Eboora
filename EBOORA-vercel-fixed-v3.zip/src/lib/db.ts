import { Pool } from "pg";

// Supports either a full DATABASE_URL or the individual variables exposed by
// Wasmer's managed PostgreSQL integration. Never log connection credentials.
function getDatabaseUrl(): string | undefined {
  const direct = process.env.DATABASE_URL?.trim();
  if (direct && !/USER:PASSWORD@HOST|your_database_url|example\.com/i.test(direct)) {
    return direct;
  }

  const host = process.env.DB_HOST?.trim();
  const database = process.env.DB_NAME?.trim();
  const username = process.env.DB_USERNAME?.trim() || process.env.DB_USER?.trim();
  const password = process.env.DB_PASSWORD;
  const port = process.env.DB_PORT?.trim() || "5432";
  if (!host || !database || !username || password === undefined ||
      /\$\{DB_/.test(host + database + username + password)) {
    return undefined;
  }

  const url = new URL(`postgresql://${encodeURIComponent(username)}:${encodeURIComponent(password)}@${host}:${port}/${encodeURIComponent(database)}`);
  // Managed PostgreSQL services commonly require TLS. Explicit sslmode in a
  // provided DATABASE_URL remains under the operator's control.
  if (process.env.DB_SSL === "true") url.searchParams.set("sslmode", "require");
  return url.toString();
}

const g = globalThis as unknown as { __ebooraPool?: Pool };
const connectionString = getDatabaseUrl();
export const pool = g.__ebooraPool ?? new Pool({
  ...(connectionString ? { connectionString } : {}),
  max: 10,
  connectionTimeoutMillis: 5000,
  idleTimeoutMillis: 30000,
  allowExitOnIdle: process.env.NODE_ENV !== "production",
});
if (process.env.NODE_ENV !== "production") g.__ebooraPool = pool;
