import { describe, it, expect } from "vitest";
import { validateProduct, validateEmail, validatePassword } from "./validation";

const base: Record<string, string> = {
  title: "Bundle", slug: "home-workout", shortDescription: "", longDescription: "",
  categoryId: "", originalPrice: "299", salePrice: "199", status: "draft", seoTitle: "", seoDescription: "",
};
const form = (o: Record<string, string> = {}) => {
  const f = new FormData();
  for (const [k, v] of Object.entries({ ...base, ...o })) f.set(k, v);
  return f;
};

describe("validateProduct", () => {
  it("converts rupees to integer paise", () => {
    const r = validateProduct(form());
    expect(r.ok && r.value.originalPricePaise).toBe(29900);
    expect(r.ok && r.value.salePricePaise).toBe(19900);
  });
  it("rejects sale price above original", () => {
    expect(validateProduct(form({ salePrice: "400" })).ok).toBe(false);
  });
  it("rejects publishing without descriptions", () => {
    expect(validateProduct(form({ status: "published" })).ok).toBe(false);
  });
  it("rejects invalid slugs", () => {
    expect(validateProduct(form({ slug: "Bad Slug!" })).ok).toBe(false);
  });
  it("rejects malformed prices", () => {
    expect(validateProduct(form({ salePrice: "19.999" })).ok).toBe(false);
  });
  it("rejects unknown statuses", () => {
    expect(validateProduct(form({ status: "live" })).ok).toBe(false);
  });
});

describe("email and password rules", () => {
  it("validates email shape", () => {
    expect(validateEmail("a@b.co")).toBe(true);
    expect(validateEmail("not-an-email")).toBe(false);
  });
  it("requires 10+ character passwords", () => {
    expect(validatePassword("short")).not.toBeNull();
    expect(validatePassword("long enough pw")).toBeNull();
  });
});
