import { describe, it, expect } from "vitest";
import { hashPassword, verifyPassword } from "./password";

describe("password hashing", () => {
  it("verifies the correct password", async () => {
    const h = await hashPassword("correct horse battery");
    expect(await verifyPassword("correct horse battery", h)).toBe(true);
  });
  it("rejects a wrong password", async () => {
    const h = await hashPassword("correct horse battery");
    expect(await verifyPassword("wrong password!!", h)).toBe(false);
  });
  it("uses a random salt for each hash", async () => {
    expect(await hashPassword("samepassword1")).not.toBe(await hashPassword("samepassword1"));
  });
  it("rejects malformed stored values", async () => {
    expect(await verifyPassword("anything", "garbage")).toBe(false);
  });
});
