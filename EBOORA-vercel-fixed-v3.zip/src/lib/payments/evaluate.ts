import type { VerifiedPaymentEvent } from "./provider";

export type OrderSnapshot = {
  id: string;
  status: "pending" | "paid" | "failed" | "cancelled" | "refunded";
  totalPaise: number;
  currency: string;
};

export type Decision =
  | { action: "mark_paid" }
  | { action: "mark_failed" }
  | { action: "ignore"; reason: string }
  | { action: "reject"; reason: string };

// Pure decision logic. Only a verified success event for a matching amount and currency
// can mark an order paid. Frontend redirects never reach this function.
export function decideFromEvent(order: OrderSnapshot | null, event: VerifiedPaymentEvent): Decision {
  if (!order) return { action: "reject", reason: "unknown_order" };
  if (event.currency !== order.currency) return { action: "reject", reason: "currency_mismatch" };

  if (event.type === "payment.success") {
    if (order.status === "paid") return { action: "ignore", reason: "already_paid" };
    if (order.status === "cancelled" || order.status === "refunded") {
      return { action: "reject", reason: "order_not_payable" };
    }
    if (event.amountPaise !== order.totalPaise) return { action: "reject", reason: "amount_mismatch" };
    return { action: "mark_paid" };
  }

  if (event.type === "payment.failed") {
    return order.status === "pending" ? { action: "mark_failed" } : { action: "ignore", reason: "not_pending" };
  }

  return { action: "ignore", reason: "not_actionable" };
}
