import { pool } from "@/lib/db";
import { enqueueOrderEmail } from "@/lib/email/queue";
import { decideFromEvent, type OrderSnapshot } from "./evaluate";
import type { VerifiedPaymentEvent } from "./provider";

export const DEFAULT_MAX_DOWNLOADS = 5;

export type ApplyInput = VerifiedPaymentEvent & { rawBodyHash: string };

// Applies one verified webhook event in a single transaction.
// Idempotent: a repeated event id is ignored, and a paid order is never paid twice.
export async function applyPaymentEvent(input: ApplyInput): Promise<{ outcome: string }> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const ins = await client.query(
      "INSERT INTO webhook_events (id, event_type) VALUES ($1, $2) ON CONFLICT (id) DO NOTHING RETURNING id",
      [input.eventId, input.type]
    );
    if (ins.rowCount === 0) {
      await client.query("COMMIT");
      return { outcome: "duplicate_event" };
    }

    const { rows: [row] } = await client.query(
      "SELECT id, status, total_paise, currency FROM orders WHERE public_order_ref = $1 FOR UPDATE",
      [input.publicOrderRef]
    );
    const order: OrderSnapshot | null = row
      ? { id: row.id, status: row.status, totalPaise: row.total_paise, currency: row.currency }
      : null;
    const decision = decideFromEvent(order, input);

    if (decision.action === "mark_paid" && order) {
      const inserted = await client.query(
        `INSERT INTO payment_transactions (order_id, provider_payment_id, amount_paise, currency, raw_event_hash)
         VALUES ($1, $2, $3, $4, $5) ON CONFLICT (provider_payment_id) DO NOTHING
         RETURNING order_id`,
        [order.id, input.providerPaymentId, input.amountPaise, input.currency, input.rawBodyHash]
      );
      if (inserted.rowCount === 0) {
        // A provider payment ID is globally unique. A reused ID must never pay a different
        // order, even if the webhook event ID itself is new. Same-order retries are safe.
        const { rows: [existingPayment] } = await client.query(
          `SELECT order_id, amount_paise, currency FROM payment_transactions
            WHERE provider_payment_id = $1 FOR UPDATE`,
          [input.providerPaymentId]
        );
        if (!existingPayment || existingPayment.order_id !== order.id ||
            existingPayment.amount_paise !== input.amountPaise || existingPayment.currency !== input.currency) {
          await client.query("INSERT INTO audit_logs (action, target) VALUES ('payment.rejected', $1)", [
            `${input.publicOrderRef}:payment_id_conflict`,
          ]);
          await client.query("UPDATE webhook_events SET processed = false WHERE id = $1", [input.eventId]);
          await client.query("COMMIT");
          return { outcome: "rejected:payment_id_conflict" };
        }
      }
      await client.query("UPDATE orders SET status = 'paid', paid_at = COALESCE(paid_at, now()) WHERE id = $1", [order.id]);
      await client.query(
        `INSERT INTO download_grants (order_id, product_file_id, max_downloads)
         SELECT $1, pf.id, $2
           FROM order_items oi
           JOIN product_files pf ON pf.product_id = oi.product_id AND pf.is_active
          WHERE oi.order_id = $1
         ON CONFLICT (order_id, product_file_id) DO NOTHING`,
        [order.id, DEFAULT_MAX_DOWNLOADS]
      );
      await enqueueOrderEmail(client, order.id, "order_confirmation");
    } else if (decision.action === "mark_failed" && order) {
      await client.query("UPDATE orders SET status = 'failed' WHERE id = $1 AND status = 'pending'", [order.id]);
      await client.query("UPDATE payment_attempts SET status = 'failed' WHERE order_id = $1", [order.id]);
      await enqueueOrderEmail(client, order.id, "payment_failed");
    } else if (decision.action === "reject") {
      await client.query("INSERT INTO audit_logs (action, target) VALUES ('payment.rejected', $1)", [
        `${input.publicOrderRef}:${decision.reason}`,
      ]);
    }

    await client.query("UPDATE webhook_events SET processed = $2 WHERE id = $1", [
      input.eventId,
      decision.action !== "reject",
    ]);
    await client.query("COMMIT");

    const outcome =
      decision.action === "reject" ? `rejected:${decision.reason}`
      : decision.action === "ignore" ? `ignored:${decision.reason}`
      : decision.action;
    return { outcome };
  } catch (e) {
    await client.query("ROLLBACK").catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}
