// Payment provider boundary. Only the Cashfree adapter touches the provider API.
//
// STATUS: The Cashfree adapter below is NOT implemented. The endpoints, request
// schema, signature algorithm, and API version must be taken from Cashfree's
// current official docs and verified in the sandbox before this throws less.
// Until then it fails closed: no order is created and no webhook is trusted.

export class PaymentNotConfiguredError extends Error {}

export type CreateProviderOrderInput = {
  publicOrderRef: string;
  amountPaise: number;
  currency: "INR";
  customerEmail: string;
  returnUrl: string;
};

export type ProviderOrder = { providerOrderId: string; paymentUrl: string };

export type VerifiedPaymentEvent = {
  eventId: string;
  type: "payment.success" | "payment.failed" | "payment.pending" | "other";
  publicOrderRef: string;
  providerOrderId: string;
  providerPaymentId: string;
  amountPaise: number;
  currency: string;
};

export interface PaymentProvider {
  createOrder(input: CreateProviderOrderInput): Promise<ProviderOrder>;
  // Must return null for any signature that is missing, invalid, or unverifiable.
  // Must verify against the exact raw request body.
  parseVerifiedWebhook(rawBody: string, headers: Headers): Promise<VerifiedPaymentEvent | null>;
}

class CashfreeProvider implements PaymentProvider {
  async createOrder(_input: CreateProviderOrderInput): Promise<ProviderOrder> {
    // TODO(verify against Cashfree docs): create order via the API using server-side
    // credentials (CASHFREE_APP_ID / CASHFREE_SECRET_KEY), sandbox or production base URL
    // selected by CASHFREE_ENV, amount conversion (paise vs rupees), and return URL placement.
    throw new PaymentNotConfiguredError("Cashfree order creation is not yet verified against current docs.");
  }

  async parseVerifiedWebhook(_rawBody: string, _headers: Headers): Promise<VerifiedPaymentEvent | null> {
    // TODO(verify against Cashfree docs): read the signature header, compute the expected
    // signature over the raw body with the webhook secret, compare in constant time,
    // then map the provider payload to VerifiedPaymentEvent.
    throw new PaymentNotConfiguredError("Cashfree webhook verification is not yet verified against current docs.");
  }
}

export function getPaymentProvider(): PaymentProvider {
  return new CashfreeProvider();
}
