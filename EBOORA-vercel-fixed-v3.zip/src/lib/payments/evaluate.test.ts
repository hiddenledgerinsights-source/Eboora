import { describe, it, expect } from "vitest";
import { decideFromEvent, type OrderSnapshot } from "./evaluate";
import type { VerifiedPaymentEvent } from "./provider";

const order = (o: Partial<OrderSnapshot> = {}): OrderSnapshot => ({
  id: "o1", status: "pending", totalPaise: 19900, currency: "INR", ...o,
});
const ev = (e: Partial<VerifiedPaymentEvent> = {}): VerifiedPaymentEvent => ({
  eventId: "evt1", type: "payment.success", publicOrderRef: "EB-x", providerOrderId: "po1",
  providerPaymentId: "pay1", amountPaise: 19900, currency: "INR", ...e,
});

describe("decideFromEvent", () => {
  it("marks a pending order paid on a matching success event", () => {
    expect(decideFromEvent(order(), ev())).toEqual({ action: "mark_paid" });
  });
  it("rejects an unknown order", () => {
    expect(decideFromEvent(null, ev())).toEqual({ action: "reject", reason: "unknown_order" });
  });
  it("rejects an amount mismatch and never marks paid", () => {
    expect(decideFromEvent(order(), ev({ amountPaise: 100 }))).toEqual({ action: "reject", reason: "amount_mismatch" });
  });
  it("rejects a currency mismatch", () => {
    expect(decideFromEvent(order(), ev({ currency: "USD" }))).toEqual({ action: "reject", reason: "currency_mismatch" });
  });
  it("ignores a duplicate success for an already-paid order", () => {
    expect(decideFromEvent(order({ status: "paid" }), ev())).toEqual({ action: "ignore", reason: "already_paid" });
  });
  it("does not mark cancelled or refunded orders paid", () => {
    expect(decideFromEvent(order({ status: "cancelled" }), ev()).action).toBe("reject");
    expect(decideFromEvent(order({ status: "refunded" }), ev()).action).toBe("reject");
  });
  it("marks a pending order failed on a failure event", () => {
    expect(decideFromEvent(order(), ev({ type: "payment.failed" }))).toEqual({ action: "mark_failed" });
  });
  it("never downgrades a paid order on a late failure event", () => {
    expect(decideFromEvent(order({ status: "paid" }), ev({ type: "payment.failed" }))).toEqual({
      action: "ignore", reason: "not_pending",
    });
  });
  it("ignores pending-state events", () => {
    expect(decideFromEvent(order(), ev({ type: "payment.pending" })).action).toBe("ignore");
  });
});
