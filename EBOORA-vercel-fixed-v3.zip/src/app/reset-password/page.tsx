import { ResetForm } from "@/components/ResetForms";
export const metadata = { title: "Set new password | EBOORA", robots: { index: false } };
export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token: searchToken } = await searchParams;
  const token = searchToken ?? "";
  if (!token) return (<><h1>Set new password</h1><p>This page needs a reset link from your email.</p></>);
  return (<><h1>Set new password</h1><ResetForm token={token} /></>);
}
