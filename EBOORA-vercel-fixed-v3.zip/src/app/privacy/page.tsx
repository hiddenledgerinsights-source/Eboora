import { LegalPage } from "@/components/LegalPage";
export const metadata = { title: "Privacy Policy | EBOORA" };
export default function Privacy() {
  return (
    <LegalPage title="Privacy Policy">
      <p>What we collect, as built today: your email and name when you register or buy; order and payment status from our payment provider (we never store card details); download logs; and, only if you accept cookies, anonymous page-view and campaign data (UTM parameters, page path, referrer domain). We do not store IP addresses in analytics.</p>
      <p>Ad pixels (Meta Pixel and Google Analytics) load only after you accept. [Name the processors and their locations, the retention periods, and your grievance officer's contact, as required by the Digital Personal Data Protection Act, 2023.]</p>
      <p>[Describe how users can access, correct, or delete their data.]</p>
    </LegalPage>
  );
}
