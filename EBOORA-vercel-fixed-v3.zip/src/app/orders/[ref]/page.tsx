import { notFound } from "next/navigation";
import { pool } from "@/lib/db";
import { PixelEvent } from "@/components/PixelEvent";

export const dynamic = "force-dynamic";

const MESSAGES: Record<string, string> = {
  pending: "We're waiting for payment confirmation. Refresh this page in a moment.",
  paid: "Payment confirmed. Your download links are in your confirmation email, and on your downloads page if you are logged in.",
  failed: "This payment did not go through. You can return to the product page and try again.",
  cancelled: "This order was cancelled.",
  refunded: "This order has been refunded.",
};

// Shows status only. Files are never delivered from this page.
// The Purchase event fires only when the server has verified payment (status = paid).
export default async function OrderPage({ params }: { params: Promise<{ ref: string }> }) {
  const { ref } = await params;
  if (!/^EB-[A-Za-z0-9_-]{10,40}$/.test(ref)) notFound();
  const { rows: [o] } = await pool.query(
    "SELECT public_order_ref, status, total_paise FROM orders WHERE public_order_ref = $1",
    [ref]
  );
  if (!o) notFound();
  return (
    <section>
      <h1>Order {o.public_order_ref}</h1>
      <p>{MESSAGES[o.status] ?? "Status unavailable."}</p>
      {o.status === "paid" && (
        <PixelEvent
          name="Purchase"
          eventId={o.public_order_ref}
          dedupeKey={o.public_order_ref}
          params={{ value: Number(o.total_paise) / 100, currency: "INR" }}
        />
      )}
    </section>
  );
}
