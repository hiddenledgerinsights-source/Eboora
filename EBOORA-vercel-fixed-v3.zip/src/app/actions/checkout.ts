"use server";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { createCheckout } from "@/lib/checkout";
import { validateEmail } from "@/lib/validation";

export type CheckoutState = { error?: string } | undefined;

export async function startCheckout(slug: string, _prev: CheckoutState, formData: FormData): Promise<CheckoutState> {
  if (!/^[a-z0-9-]{3,120}$/.test(slug)) return { error: "Product not found." };
  const user = await getCurrentUser();
  const email = (user?.email ?? String(formData.get("email") ?? "")).trim().toLowerCase();
  if (!validateEmail(email)) return { error: "Enter a valid email address." };

  const result = await createCheckout({
    slug,
    email,
    couponCode: String(formData.get("coupon") ?? "").slice(0, 40),
    userId: user?.id ?? null,
    siteUrl: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  });
  if (!result.ok) return { error: result.error };
  redirect(result.url);
}
