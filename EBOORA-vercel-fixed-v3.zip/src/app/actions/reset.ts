"use server";
import { redirect } from "next/navigation";
import { requestPasswordReset, resetPassword } from "@/lib/auth/reset";
import { validateEmail, validatePassword } from "@/lib/validation";

export type NoticeState = { error?: string; notice?: string } | undefined;

export async function forgotPassword(_prev: NoticeState, formData: FormData): Promise<NoticeState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!validateEmail(email)) return { error: "Enter a valid email address." };
  await requestPasswordReset(email);
  return { notice: "If an account exists for that email, a reset link has been sent." };
}

export async function resetPasswordAction(_prev: NoticeState, formData: FormData): Promise<NoticeState> {
  const token = String(formData.get("token") ?? "");
  const password = String(formData.get("password") ?? "");
  if (!/^[A-Za-z0-9_-]{20,100}$/.test(token)) return { error: "This reset link is invalid or has expired." };
  const pwError = validatePassword(password);
  if (pwError) return { error: pwError };
  const result = await resetPassword(token, password);
  if (!result.ok) return { error: result.error };
  redirect("/login?reset=1");
}
