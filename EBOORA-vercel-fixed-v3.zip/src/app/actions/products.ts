"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { pool } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { PRODUCT_STATUSES, UUID_RE, validateProduct } from "@/lib/validation";

export type ProductState = { error?: string } | undefined;

function refreshPublicPages() {
  revalidatePath("/");
  revalidatePath("/products");
}

export async function saveProduct(
  existingId: string | null,
  _prev: ProductState,
  formData: FormData
): Promise<ProductState> {
  const admin = await requireAdmin();
  const parsed = validateProduct(formData);
  if (!parsed.ok) return { error: parsed.error };
  const v = parsed.value;
  const params = [
    v.slug, v.title, v.shortDescription, v.longDescription, v.categoryId,
    v.originalPricePaise, v.salePricePaise, v.status, v.seoTitle, v.seoDescription,
  ];

  let id: string | null = existingId;
  try {
    if (id) {
      if (!UUID_RE.test(id)) return { error: "Product not found." };
      const { rowCount } = await pool.query(
        `UPDATE products SET slug=$2, title=$3, short_description=$4, long_description=$5,
           category_id=$6, original_price_paise=$7, sale_price_paise=$8, status=$9,
           seo_title=$10, seo_description=$11, updated_at=now()
         WHERE id=$1`,
        [id, ...params]
      );
      if (rowCount === 0) return { error: "Product not found." };
    } else {
      const { rows } = await pool.query(
        `INSERT INTO products (slug, title, short_description, long_description, category_id,
           original_price_paise, sale_price_paise, status, seo_title, seo_description)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
        params
      );
      id = rows[0].id;
    }
  } catch (e) {
    const code = (e as { code?: string }).code;
    if (code === "23505") return { error: "Another product already uses this slug." };
    if (code === "23514") return { error: "A database rule rejected these values. Check prices and status." };
    throw e;
  }

  await audit(admin.id, existingId ? "product.update" : "product.create", id);
  refreshPublicPages();
  redirect("/admin");
}

// Quick publish/unpublish/archive from the product list.
// Publishing requires both descriptions; the SQL guard enforces that server-side.
export async function setProductStatus(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = String(formData.get("id") ?? "");
  const status = String(formData.get("status") ?? "");
  if (!UUID_RE.test(id) || !(PRODUCT_STATUSES as readonly string[]).includes(status)) return;

  const { rowCount } = await pool.query(
    `UPDATE products SET status=$2, updated_at=now()
      WHERE id=$1 AND ($2 <> 'published' OR (short_description <> '' AND long_description <> ''))`,
    [id, status]
  );
  if (rowCount === 0) return;
  await audit(admin.id, `product.status:${status}`, id);
  refreshPublicPages();
  revalidatePath("/admin");
}
