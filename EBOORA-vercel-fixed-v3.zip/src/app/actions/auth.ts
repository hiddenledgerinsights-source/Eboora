"use server";
import { redirect } from "next/navigation";
import { pool } from "@/lib/db";
import { audit } from "@/lib/audit";
import { hashPassword, verifyPassword } from "@/lib/password";
import { createSession, destroySession } from "@/lib/session";
import { validateEmail, validatePassword } from "@/lib/validation";

export type AuthState = { error?: string } | undefined;

const LOGIN_WINDOW = "15 minutes";
const LOGIN_MAX_FAILURES = 10;
// Valid-format dummy hash so unknown emails cost the same time as known ones.
const DUMMY_HASH = `scrypt:${Buffer.alloc(16).toString("base64")}:${Buffer.alloc(64).toString("base64")}`;

export async function register(_prev: AuthState, formData: FormData): Promise<AuthState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const fullName = String(formData.get("fullName") ?? "").trim().slice(0, 120) || null;

  if (!validateEmail(email)) return { error: "Enter a valid email address." };
  const pwError = validatePassword(password);
  if (pwError) return { error: pwError };

  const hash = await hashPassword(password);
  try {
    const { rows } = await pool.query(
      "INSERT INTO users (email, password_hash, full_name) VALUES ($1, $2, $3) RETURNING id",
      [email, hash, fullName]
    );
    await createSession(rows[0].id);
  } catch (e) {
    if ((e as { code?: string }).code === "23505") {
      return { error: "Could not create the account. Try logging in instead." };
    }
    // A missing/placeholder database URL should never expose a raw stack trace in the UI.
    console.error("Registration failed: database unavailable or query failed.");
    return { error: "Account creation is temporarily unavailable because the database is not configured or reachable. Please try again after setup." };
  }
  redirect("/");
}

export async function login(_prev: AuthState, formData: FormData): Promise<AuthState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const generic = { error: "Email or password is incorrect." };
  if (!validateEmail(email) || !password) return generic;

  try {
    const { rows: failures } = await pool.query(
      `SELECT count(*)::int AS n FROM audit_logs
        WHERE action = 'login.failed' AND target = $1 AND created_at > now() - interval '${LOGIN_WINDOW}'`,
      [email]
    );
    if (failures[0].n >= LOGIN_MAX_FAILURES) {
      return { error: "Too many failed attempts. Try again in 15 minutes." };
    }

    const { rows } = await pool.query("SELECT id, password_hash, role FROM users WHERE email = $1", [email]);
    const user = rows[0];
    const ok = await verifyPassword(password, user?.password_hash ?? DUMMY_HASH);
    if (!user || !user.password_hash || !ok) {
      await audit(null, "login.failed", email);
      return generic;
    }

    await createSession(user.id);
    redirect(user.role === "admin" ? "/admin" : "/");
  } catch (e) {
    // Next's redirect is implemented as a thrown control-flow signal; rethrow it unchanged.
    if (typeof e === "object" && e !== null && "digest" in e && String((e as {digest?: unknown}).digest).startsWith("NEXT_REDIRECT")) throw e;
    console.error("Login failed: database unavailable or query failed.");
    return { error: "Login is temporarily unavailable because the database is not configured or reachable." };
  }
}

export async function logout(): Promise<void> {
  await destroySession();
  redirect("/");
}
