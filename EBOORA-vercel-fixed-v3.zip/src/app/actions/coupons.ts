"use server";
import { revalidatePath } from "next/cache";
import { pool } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { validateCoupon } from "@/lib/marketing/coupon-validation";
import { UUID_RE } from "@/lib/validation";

export type CouponState = { error?: string; notice?: string } | undefined;

export async function createCoupon(_prev: CouponState, formData: FormData): Promise<CouponState> {
  const admin = await requireAdmin();
  const parsed = validateCoupon(formData);
  if (!parsed.ok) return { error: parsed.error };
  const v = parsed.value;
  try {
    const { rows: [c] } = await pool.query(
      `INSERT INTO coupons (code, discount_type, discount_value, min_order_paise, product_id, max_redemptions, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
      [v.code, v.discountType, v.discountValue, v.minOrderPaise, v.productId, v.maxRedemptions, v.expiresAt]
    );
    await audit(admin.id, "coupon.create", c.id);
  } catch (e) {
    const code = (e as { code?: string }).code;
    if (code === "23505") return { error: "That code already exists." };
    if (code === "23503") return { error: "That product does not exist." };
    if (code === "23514") return { error: "Discount is out of range for its type." };
    throw e;
  }
  revalidatePath("/admin/coupons");
  return { notice: `Coupon ${v.code} created.` };
}

export async function setCouponActive(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = String(formData.get("id") ?? "");
  const active = String(formData.get("active") ?? "") === "true";
  if (!UUID_RE.test(id)) return;
  const { rowCount } = await pool.query("UPDATE coupons SET is_active = $2 WHERE id = $1", [id, active]);
  if (rowCount) await audit(admin.id, `coupon.active:${active}`, id);
  revalidatePath("/admin/coupons");
}
