"use server";
import { revalidatePath } from "next/cache";
import { pool } from "@/lib/db";
import { getCurrentUser, requireAdmin } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { UUID_RE } from "@/lib/validation";

export type ReviewState = { error?: string; notice?: string } | undefined;

// Only customers with a paid order for this product may review it. Reviews start as pending.
export async function submitReview(slug: string, _prev: ReviewState, formData: FormData): Promise<ReviewState> {
  if (!/^[a-z0-9-]{3,120}$/.test(slug)) return { error: "Product not found." };
  const user = await getCurrentUser();
  if (!user) return { error: "Log in to leave a review." };

  const rating = Number(formData.get("rating"));
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) return { error: "Choose a rating from 1 to 5." };
  const body = String(formData.get("body") ?? "").trim();
  if (body.length < 10 || body.length > 2000) return { error: "Review must be 10–2000 characters." };

  const { rows: [p] } = await pool.query("SELECT id FROM products WHERE slug = $1 AND status = 'published'", [slug]);
  if (!p) return { error: "Product not found." };
  const { rows: [bought] } = await pool.query(
    `SELECT EXISTS (SELECT 1 FROM orders o JOIN order_items oi ON oi.order_id = o.id
                     WHERE o.user_id = $1 AND oi.product_id = $2 AND o.status = 'paid') AS ok`,
    [user.id, p.id]
  );
  if (!bought.ok) return { error: "Only verified buyers can leave a review." };

  const author = (user.full_name ?? "").trim().slice(0, 60) || "Verified buyer";
  try {
    await pool.query(
      "INSERT INTO reviews (product_id, user_id, author_name, rating, body) VALUES ($1, $2, $3, $4, $5)",
      [p.id, user.id, author, rating, body]
    );
  } catch (e) {
    if ((e as { code?: string }).code === "23505") return { error: "You have already reviewed this product." };
    throw e;
  }
  revalidatePath(`/products/${slug}`);
  return { notice: "Thanks! Your review will appear after moderation." };
}

export async function setReviewStatus(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = String(formData.get("id") ?? "");
  const status = String(formData.get("status") ?? "");
  if (!UUID_RE.test(id) || !["pending", "approved", "hidden"].includes(status)) return;
  const { rows: [r] } = await pool.query(
    `UPDATE reviews SET status = $2 WHERE id = $1
     RETURNING (SELECT slug FROM products WHERE id = reviews.product_id) AS slug`,
    [id, status]
  );
  if (!r) return;
  await audit(admin.id, `review.status:${status}`, id);
  revalidatePath(`/products/${r.slug}`);
  revalidatePath("/admin/reviews");
}
