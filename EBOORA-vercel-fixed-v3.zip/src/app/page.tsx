import Link from "next/link";
import { PRODUCTS } from "@/lib/catalog";
import { formatINR } from "@/lib/pricing";

export default function Home() {
  const featured = PRODUCTS[0];
  return <>
    <section className="hero hero-editorial">
      <div className="hero-copy">
        <div className="eyebrow"><span className="eyebrow-dot" /> THE EBOORA EDIT</div>
        <h1>Less overwhelm.<br /><em>More forward.</em></h1>
        <p className="hero-lede">Useful digital resources for people who want a clear next step—not another complicated system to keep up with.</p>
        <div className="hero-actions"><Link className="btn" href="/products">Explore the collection <span aria-hidden="true">↗</span></Link><Link className="text-link" href="/about">Get to know us <span aria-hidden="true">→</span></Link></div>
        <div className="hero-proof"><span><b>01</b> Practical by design</span><span><b>02</b> Yours to revisit</span><span><b>03</b> Clear before you buy</span></div>
      </div>
      <div className="hero-visual" aria-label="A preview of a thoughtfully designed digital guide">
        <div className="visual-orbit orbit-one"/><div className="visual-orbit orbit-two"/>
        <div className="guide-sheet"><div className="sheet-top"><span>E / FIELD NOTES</span><span>VOL. 01</span></div><div className="sheet-symbol">e<span>.</span></div><div className="sheet-rule"/><div className="sheet-kicker">A SMALLER, SMARTER START</div><div className="sheet-title">Progress<br/><i>in practice.</i></div><div className="sheet-bottom"><span>MADE FOR REAL LIFE</span><span>EB—001</span></div></div>
        <div className="floating-note"><span className="note-check">✓</span><span><strong>One step at a time</strong><small>Keep it useful. Keep it moving.</small></span></div>
      </div>
    </section>
    <section className="manifesto"><div className="eyebrow">A different kind of digital product</div><p>Not more noise. <strong>Just resources that help you get going.</strong></p><span>Thoughtful structure for the things you want to make progress on.</span></section>
    <div className="section-heading"><div><div className="eyebrow">Start somewhere</div><h2>Explore the collection</h2><p>Simple, focused resources with clear pricing and details.</p></div><Link className="text-link" href="/products">View all resources <span aria-hidden="true">→</span></Link></div>
    {featured ? <div className="product-grid">{PRODUCTS.map((p, index)=><article className="product-card product-card-featured" key={p.slug}><div className={`product-cover cover-${index % 3}`}><span className="cover-label">EBOORA / GUIDE {String(index + 1).padStart(2,"0")}</span><span className="cover-glyph">{p.category === "Fitness" ? "↗" : "e."}</span><span className="cover-category">{p.category}</span></div><div className="product-card-content"><div className="eyebrow">{p.category} · DIGITAL RESOURCE</div><h3>{p.title}</h3><p>{p.shortDescription}</p><div className="card-bottom"><div className="price">{formatINR(p.salePricePaise)} <s>{formatINR(p.originalPricePaise)}</s></div><Link className="btn btn-card" href={`/products/${p.slug}`}>View details <span aria-hidden="true">↗</span></Link></div></div></article>)}</div> : <div className="notice">Our first resources are being prepared. Please check back soon.</div>}
    <section className="promise-grid"><article><span className="promise-number">01</span><h3>Clarity first</h3><p>Know what a resource includes and what it costs before making a decision.</p></article><article><span className="promise-number">02</span><h3>Made for real life</h3><p>Practical ideas and approachable structure, without unnecessary complexity.</p></article><article><span className="promise-number">03</span><h3>Support you can find</h3><p>Our delivery, refund and contact information is always easy to locate.</p></article></section>
    <section className="closing-cta"><div><div className="eyebrow">Your next step starts here</div><h2>Find the resource that fits your next move.</h2></div><Link className="btn btn-light" href="/products">Browse resources <span aria-hidden="true">↗</span></Link></section>
  </>;
}
