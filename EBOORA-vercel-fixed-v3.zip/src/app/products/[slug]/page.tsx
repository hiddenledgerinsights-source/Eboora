import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getProductBySlug } from "@/lib/catalog";
import { formatINR } from "@/lib/pricing";
import { getCurrentUser } from "@/lib/auth";
import { pool } from "@/lib/db";
import { hasAnalyticsConsent } from "@/lib/marketing/consent";
import { buildProductJsonLd, safeJsonLd } from "@/lib/marketing/jsonld";
import { siteUrl } from "@/lib/site";
import { CheckoutForm } from "@/components/CheckoutForm";
import { ReviewForm } from "@/components/ReviewForm";
import { PixelEvent } from "@/components/PixelEvent";
import { UtmCapture } from "@/components/UtmCapture";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const p = getProductBySlug(slug);
  if (!p) return { title: "Not found" };
  return { title: p.seoTitle, description: p.seoDescription, alternates: { canonical: `/products/${p.slug}` } };
}

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const p = getProductBySlug(slug);
  if (!p) notFound();
  const user = await getCurrentUser().catch(() => null);
  // The public product detail remains viewable in frontend-preview mode when PostgreSQL
  // has not been configured. Account, checkout and reviews still require a real database.
  let dbp: { id: string } | undefined;
  let dbAvailable = false;
  let reviews: Array<{ author_name: string; rating: number; body: string; created_at: string }> = [];
  try {
    const result = await pool.query("SELECT id FROM products WHERE slug = $1 AND status = 'published'", [p.slug]);
    dbAvailable = true;
    dbp = result.rows[0];
    if (dbp) {
      const reviewResult = await pool.query(
        "SELECT author_name, rating, body, created_at FROM reviews WHERE product_id = $1 AND status = 'approved' ORDER BY created_at DESC LIMIT 50",
        [dbp.id]
      );
      reviews = reviewResult.rows;
    }
  } catch {
    // Intentionally keep the public product page usable while backend services are offline.
  }
  const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : null;

  // Review eligibility, decided on the server.
  let reviewState: "anonymous" | "not_buyer" | "already_reviewed" | "can_review" = "anonymous";
  if (user && dbp) {
    const { rows: [e] } = await pool.query(
      `SELECT EXISTS (SELECT 1 FROM orders o JOIN order_items oi ON oi.order_id = o.id
                       WHERE o.user_id = $1 AND oi.product_id = $2 AND o.status = 'paid') AS bought,
              EXISTS (SELECT 1 FROM reviews WHERE user_id = $1 AND product_id = $2) AS reviewed`,
      [user.id, dbp.id]
    );
    reviewState = e.reviewed ? "already_reviewed" : e.bought ? "can_review" : "not_buyer";
  }

  const jsonLd = buildProductJsonLd({
    name: p.title,
    description: p.shortDescription,
    url: `${siteUrl()}/products/${p.slug}`,
    priceRupees: (p.salePricePaise / 100).toFixed(2),
    rating: avg !== null ? { value: avg, count: reviews.length } : null,
  });

  return (
    <article>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeJsonLd(jsonLd) }} />
      <h1>{p.title}</h1>
      <p>{p.shortDescription}</p>
      <p>
        <strong>{formatINR(p.salePricePaise)}</strong> <s>{formatINR(p.originalPricePaise)}</s>
      </p>
      <p>{p.longDescription}</p>
      {dbAvailable ? <CheckoutForm slug={p.slug} loggedInEmail={user?.email ?? null} valuePaise={p.salePricePaise} /> : <div className="notice" role="status"><strong>Preview mode</strong><p style={{marginBottom:0}}>Checkout and customer accounts will be available after the PostgreSQL database is configured.</p></div>}

      {(await hasAnalyticsConsent()) && <UtmCapture name="view_content" productSlug={p.slug} />}
      <PixelEvent
        name="ViewContent"
        params={{ content_ids: [p.slug], content_type: "product", value: p.salePricePaise / 100, currency: "INR" }}
      />

      <section style={{ marginTop: 32 }}>
        <h2>Reviews</h2>
        {avg !== null ? (
          <p>{avg.toFixed(1)} / 5 from {reviews.length} verified buyer review{reviews.length === 1 ? "" : "s"}</p>
        ) : (
          <p>No reviews yet.</p>
        )}
        <ul style={{ listStyle: "none", padding: 0 }}>
          {reviews.map((r, i) => (
            <li key={i} style={{ borderBottom: "1px solid #eee", padding: "10px 0" }}>
              <strong>{r.rating}/5</strong> — {r.author_name} <span style={{ color: "#2e7d32" }}>(verified buyer)</span>
              <p style={{ margin: "4px 0" }}>{r.body}</p>
            </li>
          ))}
        </ul>
        {reviewState === "anonymous" && <p>Log in to review after you buy.</p>}
        {reviewState === "not_buyer" && <p>Only customers who bought this product can review it.</p>}
        {reviewState === "already_reviewed" && <p>You have already reviewed this product.</p>}
        {reviewState === "can_review" && <ReviewForm slug={p.slug} />}
      </section>
    </article>
  );
}
