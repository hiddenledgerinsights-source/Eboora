import Link from "next/link";
import { PRODUCTS } from "@/lib/catalog";
import { formatINR } from "@/lib/pricing";

export default function ProductsPage() {
  return <><div className="eyebrow">EBOORA collection</div><h1>Digital guides & resources</h1><p>Explore practical resources, with clear descriptions and pricing before you buy.</p><div className="product-grid" style={{marginTop:28}}>{PRODUCTS.map(p=><article className="product-card" key={p.slug}><div className="product-icon" aria-hidden="true">{p.category === "Fitness" ? "＋" : "E"}</div><div className="eyebrow">{p.category}</div><h2>{p.title}</h2><p>{p.shortDescription}</p><div className="card-bottom"><div className="price">{formatINR(p.salePricePaise)} <s>{formatINR(p.originalPricePaise)}</s></div><Link className="btn" style={{marginTop:12}} href={`/products/${p.slug}`}>View details</Link></div></article>)}</div></>;
}
