import { LegalPage } from "@/components/LegalPage";
export const metadata = { title: "About | EBOORA" };
export default function About() {
  return (<LegalPage title="About EBOORA"><p>EBOORA sells digital fitness and skill products made for India. [Add the creator's background here, only with facts you can stand behind.]</p></LegalPage>);
}
