import { LegalPage } from "@/components/LegalPage";
export const metadata = { title: "Contact | EBOORA" };
export default function Contact() {
  return (<LegalPage title="Contact"><p>Email: [support email]. Include your order reference (EB-...) in every message.</p><p>Postal address for legal notices: [registered business address].</p></LegalPage>);
}
