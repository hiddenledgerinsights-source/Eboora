import type { ReactNode } from "react";
import "./globals.css";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { logout } from "@/app/actions/auth";
import { consentState, hasAnalyticsConsent } from "@/lib/marketing/consent";
import { gaMeasurementId, metaPixelId } from "@/lib/marketing/config";
import { GaScript, MetaPixelScript } from "@/components/Tracking";
import { ConsentBanner } from "@/components/ConsentBanner";
import { UtmCapture } from "@/components/UtmCapture";

export const metadata = { title: { default: "EBOORA | Practical digital products", template: "%s | EBOORA" }, description: "Practical digital downloads for everyday fitness and learning." };

export const viewport = { width: "device-width", initialScale: 1, maximumScale: 5, userScalable: true, viewportFit: "cover" };

const SUPPORT = process.env.NEXT_PUBLIC_SUPPORT_EMAIL ?? "";

export default async function RootLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser().catch(() => null);
  const consent = await hasAnalyticsConsent();
  const pixel = metaPixelId();
  const ga = gaMeasurementId();

  return (
    <html lang="en-IN">
      <body>
        <header className="site-header">
          <div className="header-inner"><Link href="/" className="brand">EBOORA<small>Useful digital downloads</small></Link>
          <nav className="nav-links" aria-label="Main navigation">
            {user ? (
              <>
                <Link href="/account">Account</Link>
                {user.role === "admin" && <Link href="/admin">Admin</Link>}
                <form action={logout}><button type="submit">Log out</button></form>
              </>
            ) : (
              <>
                <Link href="/login">Log in</Link>
                <Link href="/register" className="btn">Create account</Link>
              </>
            )}
          </nav></div>
        </header>
        <main className="site-main">{children}</main>
        <footer className="site-footer"><div className="footer-inner">
          <Link href="/about">About</Link>
          <Link href="/contact">Contact</Link>
          <Link href="/privacy">Privacy</Link>
          <Link href="/terms">Terms</Link>
          <Link href="/refunds">Refunds</Link>
          <Link href="/delivery">Delivery</Link>
          {SUPPORT && <span>Support: {SUPPORT}</span>}<span className="copyright">© {new Date().getFullYear()} EBOORA</span>
        </div></footer>
        {consent && pixel && <MetaPixelScript id={pixel} />}
        {consent && ga && <GaScript id={ga} />}
        {consent && <UtmCapture />}
        {(await consentState()) === null && <ConsentBanner />}
      </body>
    </html>
  );
}
