import { ForgotForm } from "@/components/ResetForms";
export const metadata = { title: "Reset password | EBOORA" };
export default function ForgotPasswordPage() {
  return (<><h1>Reset password</h1><ForgotForm /></>);
}
