import { AuthForm } from "@/components/AuthForm";
export const metadata = { title: "Create account | EBOORA" };
export default function RegisterPage() {
  return (<><h1>Create account</h1><AuthForm mode="register" /></>);
}
