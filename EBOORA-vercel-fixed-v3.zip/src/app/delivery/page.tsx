import { LegalPage } from "@/components/LegalPage";
export const metadata = { title: "Delivery Policy | EBOORA" };
export default function Delivery() {
  return (
    <LegalPage title="Digital Delivery Policy">
      <p>Files are delivered digitally. After payment is confirmed by our payment provider, we email download links and also list them on your account downloads page if you are logged in.</p>
      <p>[Confirm before publishing: the current defaults are 5 downloads per file and links valid for 30 days in the email.]</p>
      <p>If you do not receive the email within [expected time], check your spam folder, then contact support with your order reference.</p>
    </LegalPage>
  );
}
