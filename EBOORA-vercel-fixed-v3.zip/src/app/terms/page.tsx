import { LegalPage } from "@/components/LegalPage";
export const metadata = { title: "Terms | EBOORA" };
export default function Terms() {
  return (
    <LegalPage title="Terms and Conditions">
      <p>[Terms of sale, licence to use downloaded files for personal use, account rules, and governing law. To be written and reviewed.]</p>
    </LegalPage>
  );
}
