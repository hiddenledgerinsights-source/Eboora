import { requireUser } from "@/lib/auth";
import { pool } from "@/lib/db";
import { getDownloadSecret, signGrantToken } from "@/lib/downloads/token";
import { grantUnusableReason } from "@/lib/downloads/rules";

export const dynamic = "force-dynamic";

const LINK_TTL_MS = 60 * 60 * 1000; // links on this page last one hour

export default async function DownloadsPage() {
  const user = await requireUser();
  const { rows } = await pool.query(
    `SELECT dg.id, dg.max_downloads, dg.downloads_used, dg.expires_at, o.status AS order_status,
            pf.file_name, p.title
       FROM download_grants dg
       JOIN orders o ON o.id = dg.order_id
       JOIN product_files pf ON pf.id = dg.product_file_id
       JOIN products p ON p.id = pf.product_id
      WHERE o.user_id = $1 AND o.status = 'paid'
      ORDER BY o.paid_at DESC, pf.file_name`,
    [user.id]
  );
  const secret = getDownloadSecret();
  const expiresAt = Date.now() + LINK_TTL_MS;
  const now = new Date();

  return (
    <section>
      <h1>Your downloads</h1>
      {rows.length === 0 && <p>No purchased files yet.</p>}
      <ul style={{ listStyle: "none", padding: 0 }}>
        {rows.map((g) => {
          const reason = grantUnusableReason(g, now);
          const left = g.max_downloads - g.downloads_used;
          return (
            <li key={g.id} style={{ borderBottom: "1px solid #eee", padding: "12px 0" }}>
              <strong>{g.title}</strong> — {g.file_name}
              <div>
                {reason ? (
                  <span>Unavailable ({reason.replace(/_/g, " ")})</span>
                ) : (
                  <a href={`/api/download/${signGrantToken(g.id, expiresAt, secret)}`}>Download</a>
                )}
                <span style={{ marginLeft: 12, color: "#555" }}>{Math.max(left, 0)} downloads left</span>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
