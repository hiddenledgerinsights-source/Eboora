import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { pool } from "@/lib/db";
import { formatINR } from "@/lib/pricing";

export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const user = await requireUser();
  const { rows: orders } = await pool.query(
    `SELECT public_order_ref, status, total_paise, created_at FROM orders
      WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50`,
    [user.id]
  );
  return (
    <section>
      <h1>Your account</h1>
      <p>Signed in as {user.email}{user.full_name ? ` (${user.full_name})` : ""}.</p>
      <p><Link href="/account/downloads">Go to your downloads</Link></p>
      <h2>Orders</h2>
      {orders.length === 0 && <p>No orders yet.</p>}
      <ul style={{ listStyle: "none", padding: 0 }}>
        {orders.map((o) => (
          <li key={o.public_order_ref} style={{ borderBottom: "1px solid #eee", padding: "8px 0" }}>
            <Link href={`/orders/${o.public_order_ref}`}>{o.public_order_ref}</Link> — {o.status} — {formatINR(o.total_paise)}
            <span style={{ color: "#555" }}> ({new Date(o.created_at).toLocaleDateString("en-IN")})</span>
          </li>
        ))}
      </ul>
      <p style={{ color: "#555" }}>Email preferences are not available yet.</p>
    </section>
  );
}
