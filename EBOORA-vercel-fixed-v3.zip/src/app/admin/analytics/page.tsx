import { pool } from "@/lib/db";
import { formatINR } from "@/lib/pricing";

export const dynamic = "force-dynamic";

export default async function AnalyticsPage() {
  const [{ rows: byName }, { rows: sources }, { rows: campaigns }, { rows: [sales] }] = await Promise.all([
    pool.query(
      "SELECT name, count(*)::int AS n FROM analytics_events WHERE created_at > now() - interval '30 days' GROUP BY name ORDER BY n DESC"
    ),
    pool.query(
      `SELECT COALESCE(utm_source, '(none)') AS k, count(*)::int AS n FROM analytics_events
        WHERE name = 'page_view' AND created_at > now() - interval '30 days' GROUP BY 1 ORDER BY n DESC LIMIT 10`
    ),
    pool.query(
      `SELECT COALESCE(utm_campaign, '(none)') AS k, count(*)::int AS n FROM analytics_events
        WHERE name = 'page_view' AND created_at > now() - interval '30 days' GROUP BY 1 ORDER BY n DESC LIMIT 10`
    ),
    pool.query(
      `SELECT count(*)::int AS orders, COALESCE(SUM(total_paise), 0)::bigint AS revenue
         FROM orders WHERE status = 'paid' AND paid_at > now() - interval '30 days'`
    ),
  ]);
  const revenue = Number(sales.revenue);
  const aov = sales.orders > 0 ? revenue / sales.orders : 0;

  const Table = ({ title, rows }: { title: string; rows: { k?: string; name?: string; n: number }[] }) => (
    <div>
      <h3>{title}</h3>
      {rows.length === 0 ? <p>No data in the last 30 days.</p> : (
        <table><tbody>{rows.map((r, i) => <tr key={i}><td style={{ paddingRight: 24 }}>{r.k ?? r.name}</td><td>{r.n}</td></tr>)}</tbody></table>
      )}
    </div>
  );

  return (
    <section>
      <h1>Analytics (last 30 days)</h1>
      <p>Verified sales are paid orders only, from the server-side payment record.</p>
      <ul>
        <li>Verified orders: {sales.orders}</li>
        <li>Revenue: {formatINR(revenue)}</li>
        <li>Average order value: {formatINR(aov)}</li>
      </ul>
      <Table title="Events" rows={byName} />
      <Table title="Traffic sources (utm_source)" rows={sources} />
      <Table title="Campaigns (utm_campaign)" rows={campaigns} />
      <p style={{ color: "#555" }}>Pixel and GA dashboards remain the source for ad-platform attribution.</p>
    </section>
  );
}
