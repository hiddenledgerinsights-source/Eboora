import Link from "next/link";
import { pool } from "@/lib/db";
import { formatINR } from "@/lib/pricing";
import { setProductStatus } from "@/app/actions/products";

export const dynamic = "force-dynamic";

export default async function AdminProducts() {
  const { rows } = await pool.query(
    "SELECT id, title, status, sale_price_paise FROM products ORDER BY updated_at DESC"
  );
  return (
    <section>
      <h1>Products</h1>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr><th align="left">Title</th><th align="left">Price</th><th align="left">Status</th></tr>
        </thead>
        <tbody>
          {rows.map((p) => (
            <tr key={p.id}>
              <td><Link href={`/admin/products/${p.id}`}>{p.title}</Link></td>
              <td>{formatINR(p.sale_price_paise)}</td>
              <td>
                <form action={setProductStatus} style={{ display: "flex", gap: 8 }}>
                  <input type="hidden" name="id" value={p.id} />
                  <select name="status" defaultValue={p.status}>
                    <option value="draft">draft</option>
                    <option value="published">published</option>
                    <option value="archived">archived</option>
                  </select>
                  <button type="submit">Save</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length === 0 && <p>No products yet.</p>}
    </section>
  );
}
