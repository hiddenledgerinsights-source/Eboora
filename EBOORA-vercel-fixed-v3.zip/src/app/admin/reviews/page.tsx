import { pool } from "@/lib/db";
import { setReviewStatus } from "@/app/actions/reviews";

export const dynamic = "force-dynamic";

export default async function ReviewsPage() {
  const { rows } = await pool.query(
    `SELECT r.id, r.rating, r.body, r.status, r.author_name, p.title
       FROM reviews r JOIN products p ON p.id = r.product_id
      ORDER BY (r.status = 'pending') DESC, r.created_at DESC LIMIT 200`
  );
  return (
    <section>
      <h1>Review moderation</h1>
      <p>Only real purchases can be reviewed. Never add invented reviews.</p>
      {rows.length === 0 && <p>No reviews yet.</p>}
      <ul style={{ listStyle: "none", padding: 0 }}>
        {rows.map((r) => (
          <li key={r.id} style={{ borderBottom: "1px solid #eee", padding: "10px 0" }}>
            <strong>{r.title}</strong> — {r.rating}/5 by {r.author_name} <em>[{r.status}]</em>
            <p style={{ margin: "4px 0" }}>{r.body}</p>
            {(["approved", "hidden"] as const).map((s) => (
              <form key={s} action={setReviewStatus} style={{ display: "inline", marginRight: 8 }}>
                <input type="hidden" name="id" value={r.id} />
                <input type="hidden" name="status" value={s} />
                <button type="submit" disabled={r.status === s}>{s === "approved" ? "Approve" : "Hide"}</button>
              </form>
            ))}
          </li>
        ))}
      </ul>
    </section>
  );
}
