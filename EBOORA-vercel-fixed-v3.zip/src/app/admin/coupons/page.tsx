import { pool } from "@/lib/db";
import { CouponForm } from "@/components/CouponForm";
import { setCouponActive } from "@/app/actions/coupons";
import { formatINR } from "@/lib/pricing";

export const dynamic = "force-dynamic";

export default async function CouponsPage() {
  const [{ rows: coupons }, { rows: products }] = await Promise.all([
    pool.query(
      `SELECT c.id, c.code, c.discount_type, c.discount_value, c.min_order_paise, c.max_redemptions,
              c.expires_at, c.is_active,
              (SELECT count(*)::int FROM orders o WHERE o.coupon_id = c.id AND o.status = 'paid') AS used
         FROM coupons c ORDER BY c.code`
    ),
    pool.query("SELECT id, title FROM products ORDER BY title"),
  ]);
  return (
    <section>
      <h1>Coupons</h1>
      <h2>Create</h2>
      <CouponForm products={products} />
      <h2 style={{ marginTop: 32 }}>Existing</h2>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr><th align="left">Code</th><th align="left">Discount</th><th align="left">Min order</th><th align="left">Used / max</th><th align="left">Expires</th><th align="left">Status</th></tr>
        </thead>
        <tbody>
          {coupons.map((c) => (
            <tr key={c.id}>
              <td>{c.code}</td>
              <td>{c.discount_type === "percent" ? `${c.discount_value}%` : formatINR(c.discount_value)}</td>
              <td>{formatINR(c.min_order_paise)}</td>
              <td>{c.used} / {c.max_redemptions ?? "∞"}</td>
              <td>{c.expires_at ? new Date(c.expires_at).toLocaleDateString("en-IN") : "—"}</td>
              <td>
                <form action={setCouponActive} style={{ display: "inline" }}>
                  <input type="hidden" name="id" value={c.id} />
                  <input type="hidden" name="active" value={String(!c.is_active)} />
                  <button type="submit">{c.is_active ? "Deactivate" : "Activate"}</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
