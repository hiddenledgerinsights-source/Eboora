import Link from "next/link";
import type { ReactNode } from "react";
import { requireAdmin } from "@/lib/auth";
import { logout } from "@/app/actions/auth";

// Every admin route passes through this server-side check; the UI is never the gate.
export default async function AdminLayout({ children }: { children: ReactNode }) {
  const admin = await requireAdmin();
  return (
    <div>
      <nav style={{ display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap" }}>
        <strong>Admin</strong>
        <Link href="/admin">Products</Link>
        <Link href="/admin/products/new">New product</Link>
        <Link href="/admin/coupons">Coupons</Link>
        <Link href="/admin/reviews">Reviews</Link>
        <Link href="/admin/analytics">Analytics</Link>
        <span style={{ marginLeft: "auto" }}>{admin.email}</span>
        <form action={logout}><button type="submit">Log out</button></form>
      </nav>
      <hr />
      {children}
    </div>
  );
}
