import { notFound } from "next/navigation";
import { pool } from "@/lib/db";
import { ProductForm } from "@/components/ProductForm";
import { UUID_RE } from "@/lib/validation";

export const dynamic = "force-dynamic";

export default async function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!UUID_RE.test(id)) notFound();
  const [productRes, categoriesRes] = await Promise.all([
    pool.query("SELECT * FROM products WHERE id = $1", [id]),
    pool.query("SELECT id, name FROM categories ORDER BY name"),
  ]);
  const p = productRes.rows[0];
  if (!p) notFound();
  const defaults = {
    title: p.title,
    slug: p.slug,
    shortDescription: p.short_description,
    longDescription: p.long_description,
    categoryId: p.category_id ?? "",
    originalPrice: (p.original_price_paise / 100).toFixed(2),
    salePrice: (p.sale_price_paise / 100).toFixed(2),
    status: p.status,
    seoTitle: p.seo_title ?? "",
    seoDescription: p.seo_description ?? "",
  };
  return (
    <>
      <h1>Edit product</h1>
      <ProductForm productId={p.id} defaults={defaults} categories={categoriesRes.rows} />
    </>
  );
}
