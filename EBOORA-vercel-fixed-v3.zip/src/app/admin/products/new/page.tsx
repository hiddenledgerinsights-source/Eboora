import { pool } from "@/lib/db";
import { ProductForm, type ProductDefaults } from "@/components/ProductForm";

export const dynamic = "force-dynamic";

const EMPTY: ProductDefaults = {
  title: "", slug: "", shortDescription: "", longDescription: "", categoryId: "",
  originalPrice: "", salePrice: "", status: "draft", seoTitle: "", seoDescription: "",
};

export default async function NewProductPage() {
  const { rows: categories } = await pool.query("SELECT id, name FROM categories ORDER BY name");
  return (
    <>
      <h1>New product</h1>
      <ProductForm productId={null} defaults={EMPTY} categories={categories} />
    </>
  );
}
