import { getDownloadSecret, verifyGrantToken } from "@/lib/downloads/token";
import { serveGrant } from "@/lib/downloads/serve";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ token: string }> }): Promise<Response> {
  const { token } = await params;
  const verified = verifyGrantToken(token, getDownloadSecret(), Date.now());
  if (!verified) {
    return new Response("This download link is invalid or has expired.", {
      status: 403,
      headers: { "Cache-Control": "no-store" },
    });
  }
  return serveGrant(verified.grantId);
}
