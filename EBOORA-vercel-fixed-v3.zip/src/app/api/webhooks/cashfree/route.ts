import { createHash } from "node:crypto";
import { getPaymentProvider, PaymentNotConfiguredError } from "@/lib/payments/provider";
import { applyPaymentEvent } from "@/lib/payments/fulfill";
import { sendQueuedEmails } from "@/lib/email/queue";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: Request): Promise<Response> {
  // Read the raw body once; signature verification must use these exact bytes.
  const rawBody = await req.text();
  let event;
  try {
    event = await getPaymentProvider().parseVerifiedWebhook(rawBody, req.headers);
  } catch (e) {
    if (e instanceof PaymentNotConfiguredError) {
      // 503 makes the provider retry later instead of treating the event as delivered.
      return new Response("Payment provider not configured", { status: 503 });
    }
    throw e;
  }
  if (!event) return new Response("Invalid signature", { status: 400 });

  const rawBodyHash = createHash("sha256").update(rawBody).digest("hex");
  const result = await applyPaymentEvent({ ...event, rawBodyHash });

  // Best effort. Anything not sent stays queued and the scheduled job retries it.
  await sendQueuedEmails(10).catch(() => console.error("webhook: email batch failed"));
  return Response.json({ outcome: result.outcome });
}
