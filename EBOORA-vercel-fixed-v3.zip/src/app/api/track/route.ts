import { pool } from "@/lib/db";
import { hasAnalyticsConsent } from "@/lib/marketing/consent";
import { sanitizeUtm } from "@/lib/marketing/utm";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const NAMES = new Set(["page_view", "view_content", "checkout_start"]);
const SLUG_RE = /^[a-z0-9-]{3,120}$/;

// First-party analytics. Stores no IP address and no user ID. Path is generalised for order pages.
export async function POST(req: Request): Promise<Response> {
  if (!(await hasAnalyticsConsent())) return new Response(null, { status: 204 });

  const raw = await req.text();
  if (raw.length > 2000) return new Response(null, { status: 413 });

  let body: Record<string, unknown>;
  try {
    body = JSON.parse(raw);
  } catch {
    return new Response(null, { status: 400 });
  }
  const name = body.name;
  const rawPath = typeof body.path === "string" ? body.path : "";
  if (typeof name !== "string" || !NAMES.has(name) || !rawPath.startsWith("/") || rawPath.length > 300) {
    return new Response(null, { status: 400 });
  }
  const path = rawPath.startsWith("/orders/") ? "/orders/[ref]" : rawPath.split("?")[0];
  const slug = typeof body.productSlug === "string" && SLUG_RE.test(body.productSlug) ? body.productSlug : null;

  let referrerHost: string | null = null;
  try {
    const r = req.headers.get("referer");
    if (r) referrerHost = new URL(r).host.slice(0, 120);
  } catch {
    referrerHost = null;
  }

  await pool.query(
    `INSERT INTO analytics_events (name, path, product_id, utm_source, utm_medium, utm_campaign, referrer_host)
     VALUES ($1, $2, (SELECT id FROM products WHERE slug = $3), $4, $5, $6, $7)`,
    [
      name, path, slug,
      sanitizeUtm(body.utm_source), sanitizeUtm(body.utm_medium), sanitizeUtm(body.utm_campaign),
      referrerHost,
    ]
  );
  return new Response(null, { status: 204 });
}
