import { pool } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// Intentionally reveals no credentials, hostnames, or internal error details.
export async function GET(): Promise<Response> {
  try {
    await pool.query('SELECT 1');
    return Response.json({ status: 'ok', database: 'ok' }, {
      status: 200,
      headers: { 'Cache-Control': 'no-store' },
    });
  } catch {
    return Response.json({ status: 'degraded', database: 'unavailable' }, {
      status: 503,
      headers: { 'Cache-Control': 'no-store' },
    });
  }
}
