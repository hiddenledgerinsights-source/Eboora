import { timingSafeEqual } from "node:crypto";
import { sendQueuedEmails } from "@/lib/email/queue";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Called by a scheduler with "Authorization: Bearer <CRON_SECRET>". Fails closed if unset.
export async function POST(req: Request): Promise<Response> {
  const secret = process.env.CRON_SECRET ?? "";
  const header = Buffer.from(req.headers.get("authorization") ?? "");
  const expected = Buffer.from(`Bearer ${secret}`);
  if (secret.length < 32 || header.length !== expected.length || !timingSafeEqual(header, expected)) {
    return new Response("Unauthorized", { status: 401 });
  }
  return Response.json(await sendQueuedEmails(50));
}
