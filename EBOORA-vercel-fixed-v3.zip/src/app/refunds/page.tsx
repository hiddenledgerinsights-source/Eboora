import { LegalPage } from "@/components/LegalPage";
export const metadata = { title: "Refund Policy | EBOORA" };
export default function Refunds() {
  return (
    <LegalPage title="Refund Policy">
      <p>[Refund terms are not decided yet. Do not publish this page until the seller has chosen a policy and it has been checked against the Consumer Protection Act, 2019, and the payment provider's terms.]</p>
    </LegalPage>
  );
}
