import Link from "next/link";
import { AuthForm } from "@/components/AuthForm";
export const metadata = { title: "Log in | EBOORA" };
export default function LoginPage() {
  return (
    <>
      <h1>Log in</h1>
      <AuthForm mode="login" />
      <p><Link href="/forgot-password">Forgot password?</Link></p>
    </>
  );
}
