import type { MetadataRoute } from "next";
import { pool } from "@/lib/db";
import { siteUrl } from "@/lib/site";

export const revalidate = 3600;

const STATIC = ["", "/products", "/about", "/contact", "/privacy", "/terms", "/refunds", "/delivery"];

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = siteUrl();
  const entries: MetadataRoute.Sitemap = STATIC.map((p) => ({ url: `${base}${p}` }));
  try {
    const { rows } = await pool.query("SELECT slug, updated_at FROM products WHERE status = 'published'");
    for (const r of rows) entries.push({ url: `${base}/products/${r.slug}`, lastModified: r.updated_at });
  } catch {
    // Database unreachable at build time: ship the static entries only.
  }
  return entries;
}
