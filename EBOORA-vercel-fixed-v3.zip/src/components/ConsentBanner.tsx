"use client";

export function ConsentBanner() {
  const choose = (value: "granted" | "denied") => {
    const secure = window.location.protocol === "https:" ? "; Secure" : "";
    document.cookie = `eb_consent=${value}; path=/; max-age=15552000; SameSite=Lax${secure}`;
    window.location.reload();
  };
  return (
    <div
      role="dialog"
      aria-label="Cookie consent"
      style={{
        position: "fixed", left: 12, right: 12, bottom: 12, maxWidth: 640, margin: "0 auto",
        background: "#fff", border: "1px solid #ddd", borderRadius: 8, padding: 16,
        boxShadow: "0 2px 12px rgba(0,0,0,0.12)", display: "grid", gap: 8, zIndex: 50,
      }}
    >
      <p style={{ margin: 0 }}>
        We use cookies to measure ads and improve the store, only if you agree.{" "}
        <a href="/privacy">Privacy policy</a>
      </p>
      <div style={{ display: "flex", gap: 8 }}>
        <button type="button" onClick={() => choose("granted")}>Accept</button>
        <button type="button" onClick={() => choose("denied")}>Reject</button>
      </div>
    </div>
  );
}
