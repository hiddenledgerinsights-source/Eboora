"use client";
import { useEffect } from "react";
import { trackPixel } from "@/lib/marketing/pixel-client";

// Fires one standard Pixel event on mount. dedupeKey stops repeats on page refresh.
export function PixelEvent(props: {
  name: string;
  params: Record<string, unknown>;
  eventId?: string;
  dedupeKey?: string;
}) {
  const { name, params, eventId, dedupeKey } = props;
  useEffect(() => {
    const key = dedupeKey ? `ebpx:${name}:${dedupeKey}` : null;
    try {
      if (key && localStorage.getItem(key)) return;
    } catch {
      /* storage unavailable: fire anyway */
    }
    let tries = 0;
    const attempt = () => {
      const fbq = (window as unknown as { fbq?: unknown }).fbq;
      if (typeof fbq !== "function") {
        // Pixel script loads asynchronously; retry briefly, then give up silently.
        if (++tries < 20) setTimeout(attempt, 250);
        return;
      }
      trackPixel(name, params, eventId);
      try {
        if (key) localStorage.setItem(key, "1");
      } catch {
        /* ignore */
      }
    };
    attempt();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [name, eventId, dedupeKey]);
  return null;
}
