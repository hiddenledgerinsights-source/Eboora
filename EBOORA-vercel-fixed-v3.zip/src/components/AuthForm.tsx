"use client";
import { useFormState } from "react-dom";
import { login, register, type AuthState } from "@/app/actions/auth";
import { SubmitButton } from "./SubmitButton";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const [state, formAction] = useFormState<AuthState, FormData>(
    mode === "login" ? login : register,
    undefined
  );
  return (
    <form action={formAction} style={{ display: "grid", gap: 12, maxWidth: 360 }}>
      {mode === "register" && (
        <label>Full name<input name="fullName" autoComplete="name" maxLength={120} /></label>
      )}
      <label>Email<input name="email" type="email" required autoComplete="email" /></label>
      <label>
        Password
        <input
          name="password"
          type="password"
          required
          minLength={mode === "register" ? 10 : undefined}
          autoComplete={mode === "login" ? "current-password" : "new-password"}
        />
      </label>
      {state?.error && <p role="alert" style={{ color: "#b00020" }}>{state.error}</p>}
      <SubmitButton label={mode === "login" ? "Log in" : "Create account"} />
    </form>
  );
}
