"use client";
import { useFormState } from "react-dom";
import { createCoupon, type CouponState } from "@/app/actions/coupons";
import { SubmitButton } from "./SubmitButton";

export function CouponForm({ products }: { products: { id: string; title: string }[] }) {
  const [state, action] = useFormState<CouponState, FormData>(createCoupon, undefined);
  return (
    <form action={action} style={{ display: "grid", gap: 10, maxWidth: 520 }}>
      <label>Code<input name="code" required maxLength={20} /></label>
      <label>
        Type
        <select name="discountType" defaultValue="percent">
          <option value="percent">Percent (%)</option>
          <option value="fixed">Fixed (₹)</option>
        </select>
      </label>
      <label>Discount value<input name="discountValue" required inputMode="decimal" /></label>
      <label>Minimum order (₹, optional)<input name="minOrder" inputMode="decimal" placeholder="0" /></label>
      <label>
        Product (optional)
        <select name="productId" defaultValue="">
          <option value="">All products</option>
          {products.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
        </select>
      </label>
      <label>Max redemptions (optional)<input name="maxRedemptions" inputMode="numeric" /></label>
      <label>Expires on (optional)<input name="expiresOn" type="date" /></label>
      {state?.error && <p role="alert" style={{ color: "#b00020" }}>{state.error}</p>}
      {state?.notice && <p role="status">{state.notice}</p>}
      <SubmitButton label="Create coupon" />
    </form>
  );
}
