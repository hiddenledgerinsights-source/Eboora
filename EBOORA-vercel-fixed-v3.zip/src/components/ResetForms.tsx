"use client";
import { useFormState } from "react-dom";
import { forgotPassword, resetPasswordAction, type NoticeState } from "@/app/actions/reset";
import { SubmitButton } from "./SubmitButton";

export function ForgotForm() {
  const [state, action] = useFormState<NoticeState, FormData>(forgotPassword, undefined);
  return (
    <form action={action} style={{ display: "grid", gap: 12, maxWidth: 360 }}>
      <label>Email<input name="email" type="email" required autoComplete="email" /></label>
      {state?.error && <p role="alert" style={{ color: "#b00020" }}>{state.error}</p>}
      {state?.notice && <p role="status">{state.notice}</p>}
      <SubmitButton label="Send reset link" />
    </form>
  );
}

export function ResetForm({ token }: { token: string }) {
  const [state, action] = useFormState<NoticeState, FormData>(resetPasswordAction, undefined);
  return (
    <form action={action} style={{ display: "grid", gap: 12, maxWidth: 360 }}>
      <input type="hidden" name="token" value={token} />
      <label>
        New password
        <input name="password" type="password" required minLength={10} autoComplete="new-password" />
      </label>
      {state?.error && <p role="alert" style={{ color: "#b00020" }}>{state.error}</p>}
      <SubmitButton label="Set new password" />
    </form>
  );
}
