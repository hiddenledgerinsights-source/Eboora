"use client";
import { useFormState } from "react-dom";
import { submitReview, type ReviewState } from "@/app/actions/reviews";
import { SubmitButton } from "./SubmitButton";

export function ReviewForm({ slug }: { slug: string }) {
  const [state, action] = useFormState<ReviewState, FormData>(submitReview.bind(null, slug), undefined);
  return (
    <form action={action} style={{ display: "grid", gap: 8, maxWidth: 480 }}>
      <label>
        Rating
        <select name="rating" defaultValue="5">
          {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{n} / 5</option>)}
        </select>
      </label>
      <label>Your review<textarea name="body" rows={4} minLength={10} maxLength={2000} required /></label>
      {state?.error && <p role="alert" style={{ color: "#b00020" }}>{state.error}</p>}
      {state?.notice && <p role="status">{state.notice}</p>}
      <SubmitButton label="Submit review" />
    </form>
  );
}
