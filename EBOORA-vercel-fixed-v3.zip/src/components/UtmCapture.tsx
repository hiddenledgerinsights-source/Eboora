"use client";
import { useEffect } from "react";

// Sends one first-party analytics event. Rendered only after consent; the server re-checks consent.
export function UtmCapture({ name = "page_view", productSlug }: { name?: string; productSlug?: string }) {
  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    const body = {
      name,
      path: window.location.pathname,
      productSlug: productSlug ?? null,
      utm_source: p.get("utm_source"),
      utm_medium: p.get("utm_medium"),
      utm_campaign: p.get("utm_campaign"),
    };
    fetch("/api/track", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      keepalive: true,
    }).catch(() => {});
  }, [name, productSlug]);
  return null;
}
