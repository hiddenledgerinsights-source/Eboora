"use client";
import { useFormState } from "react-dom";
import { saveProduct, type ProductState } from "@/app/actions/products";
import { SubmitButton } from "./SubmitButton";

export type ProductDefaults = {
  title: string; slug: string; shortDescription: string; longDescription: string;
  categoryId: string; originalPrice: string; salePrice: string; status: string;
  seoTitle: string; seoDescription: string;
};

export function ProductForm({
  productId, defaults, categories,
}: {
  productId: string | null;
  defaults: ProductDefaults;
  categories: { id: string; name: string }[];
}) {
  const [state, formAction] = useFormState<ProductState, FormData>(
    saveProduct.bind(null, productId),
    undefined
  );
  const field = (label: string, name: keyof ProductDefaults, extra: object = {}) => (
    <label style={{ display: "grid", gap: 4 }}>
      {label}
      <input name={name} defaultValue={defaults[name]} {...extra} />
    </label>
  );
  return (
    <form action={formAction} style={{ display: "grid", gap: 12, maxWidth: 640 }}>
      {field("Title", "title", { required: true, maxLength: 200 })}
      {field("Slug", "slug", { required: true, pattern: "[a-z0-9-]{3,120}" })}
      <label style={{ display: "grid", gap: 4 }}>
        Short description
        <textarea name="shortDescription" defaultValue={defaults.shortDescription} maxLength={300} />
      </label>
      <label style={{ display: "grid", gap: 4 }}>
        Long description
        <textarea name="longDescription" rows={6} defaultValue={defaults.longDescription} />
      </label>
      <label style={{ display: "grid", gap: 4 }}>
        Category
        <select name="categoryId" defaultValue={defaults.categoryId}>
          <option value="">None</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </label>
      {field("Original price (₹)", "originalPrice", { required: true, inputMode: "decimal" })}
      {field("Sale price (₹)", "salePrice", { required: true, inputMode: "decimal" })}
      <label style={{ display: "grid", gap: 4 }}>
        Status
        <select name="status" defaultValue={defaults.status}>
          <option value="draft">draft</option>
          <option value="published">published</option>
          <option value="archived">archived</option>
        </select>
      </label>
      {field("SEO title", "seoTitle", { maxLength: 70 })}
      <label style={{ display: "grid", gap: 4 }}>
        SEO description
        <textarea name="seoDescription" defaultValue={defaults.seoDescription} maxLength={160} />
      </label>
      {state?.error && <p role="alert" style={{ color: "#b00020" }}>{state.error}</p>}
      <SubmitButton label={productId ? "Save changes" : "Create product"} />
    </form>
  );
}
