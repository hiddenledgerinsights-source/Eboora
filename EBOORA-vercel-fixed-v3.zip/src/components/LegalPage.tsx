import type { ReactNode } from "react";

// Every legal page is a draft until a qualified person reviews it. Placeholders are in [brackets].
export function LegalPage({ title, children }: { title: string; children: ReactNode }) {
  return (
    <article style={{ lineHeight: 1.6 }}>
      <p style={{ background: "#fff8e1", padding: 8, borderRadius: 6, fontSize: 14 }}>
        DRAFT: not legal advice. Fill in the [bracketed] details and have it reviewed before publishing.
      </p>
      <h1>{title}</h1>
      {children}
    </article>
  );
}
