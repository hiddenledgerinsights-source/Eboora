"use client";
import { useFormState } from "react-dom";
import { startCheckout, type CheckoutState } from "@/app/actions/checkout";
import { SubmitButton } from "./SubmitButton";
import { trackPixel } from "@/lib/marketing/pixel-client";

export function CheckoutForm({ slug, loggedInEmail, valuePaise }: { slug: string; loggedInEmail: string | null; valuePaise: number }) {
  const [state, action] = useFormState<CheckoutState, FormData>(startCheckout.bind(null, slug), undefined);
  return (
    <form
      action={action}
      onSubmit={() => trackPixel("InitiateCheckout", { value: valuePaise / 100, currency: "INR" })}
      style={{ display: "grid", gap: 8, maxWidth: 360 }}
    >
      {!loggedInEmail && (
        <label>Email for your receipt and downloads<input name="email" type="email" required autoComplete="email" /></label>
      )}
      <label>Coupon code (optional)<input name="coupon" maxLength={40} autoComplete="off" /></label>
      {state?.error && <p role="alert" style={{ color: "#b00020" }}>{state.error}</p>}
      <SubmitButton label="Continue to secure payment" />
    </form>
  );
}
