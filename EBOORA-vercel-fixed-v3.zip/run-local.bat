@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js 20+ is required. & pause & exit /b 1)
if not exist .env.local copy .env.example .env.local
if not exist node_modules npm install
 echo Starting EBOORA. Ensure PostgreSQL is running and .env.local is configured.
npm run dev
pause
